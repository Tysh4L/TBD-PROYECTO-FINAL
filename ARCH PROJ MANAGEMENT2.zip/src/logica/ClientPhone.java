package logica;

public class ClientPhone {
    private int clientId;
    private String phoneNumber;

    public ClientPhone() {
    }

    public ClientPhone(int clientId, String phoneNumber) {
        this.clientId = clientId;
        this.phoneNumber = phoneNumber;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    
}
