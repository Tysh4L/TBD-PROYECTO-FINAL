package logica;

import java.math.BigDecimal;

public class StageSubcontractor {

    private int projectId;
    private int stageId;
    private int subcontractorId;
    private String projectName;
    private String stageName;
    private String companyName;
    private int hoursUsed;
    private BigDecimal subcontractorCost;

    // Constructor para insertar/actualizar
    public StageSubcontractor(int projectId, int stageId, int subcontractorId, int hoursUsed, BigDecimal subcontractorCost) {
        this.projectId = projectId;
        this.stageId = stageId;
        this.subcontractorId = subcontractorId;
        this.hoursUsed = hoursUsed;
        this.subcontractorCost = subcontractorCost;
    }

    // Constructor para cargar datos
    public StageSubcontractor(int projectId, String projectName, String stageName, String companyName, int hoursUsed, BigDecimal subcontractorCost) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.stageName = stageName;
        this.companyName = companyName;
        this.hoursUsed = hoursUsed;
        this.subcontractorCost = subcontractorCost;

    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public int getStageId() {
        return stageId;
    }

    public void setStageId(int stageId) {
        this.stageId = stageId;
    }

    public int getSubcontractorId() {
        return subcontractorId;
    }

    public void setSubcontractorId(int subcontractorId) {
        this.subcontractorId = subcontractorId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getHoursUsed() {
        return hoursUsed;
    }

    public void setHoursUsed(int hoursUsed) {
        this.hoursUsed = hoursUsed;
    }

    public BigDecimal getSubcontractorCost() {
        return subcontractorCost;
    }

    public void setSubcontractorCost(BigDecimal subcontractorCost) {
        this.subcontractorCost = subcontractorCost;
    }

}
