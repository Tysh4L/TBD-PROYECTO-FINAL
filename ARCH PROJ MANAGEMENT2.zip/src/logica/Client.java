package logica;

import java.util.Date;

public class Client {
    private int clientId;
    private String firstName;
    private String lastName;
    private String companyName;
    private String rfc;
    private String email;
    private String gender;
    private java.sql.Date birthDate;
    private int addressId;
    

    public Client() {
    }

    public Client(int clientId, String firstName, String lastName, String companyName, String rfc, String email, String gender, java.sql.Date birthDate, int addressId) {
        this.clientId = clientId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.companyName = companyName;
        this.rfc = rfc;
        this.email = email;
        this.gender = gender;
        this.birthDate = birthDate;
        this.addressId = addressId;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

public java.sql.Date getBirthDate() {
    return birthDate;
}

public void setBirthDate(java.sql.Date birthDate) {
    this.birthDate = birthDate;
}
    
    
    
    
    
}
