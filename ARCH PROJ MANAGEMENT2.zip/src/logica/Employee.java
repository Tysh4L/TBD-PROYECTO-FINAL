package logica;

import java.math.BigDecimal;
import java.util.Date;

public class Employee {
    private int employeeId;
    private String firstName;
    private String lastName;
    private Date birthDate;
    private String gender;
    private String rfc;
    private String email;
    private int addressId;

    private int departmentId;
    private int buId;
    private int jobPositionId;
    private int specializationId;
    private Date hireDate;
    private BigDecimal monthlySalary;

    public Employee() {
    }

    public Employee(int employeeId, String firstName, String lastName, Date birthDate, String gender, String rfc,
                    String email, int addressId, int departmentId, int buId, int jobPositionId, int specializationId,
                    Date hireDate, BigDecimal monthlySalary) {
        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.gender = gender;
        this.rfc = rfc;
        this.email = email;
        this.addressId = addressId;
        this.departmentId = departmentId;
        this.buId = buId;
        this.jobPositionId = jobPositionId;
        this.specializationId = specializationId;
        this.hireDate = hireDate;
        this.monthlySalary = monthlySalary;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public int getBuId() {
        return buId;
    }

    public void setBuId(int buId) {
        this.buId = buId;
    }

    public int getJobPositionId() {
        return jobPositionId;
    }

    public void setJobPositionId(int jobPositionId) {
        this.jobPositionId = jobPositionId;
    }

    public int getSpecializationId() {
        return specializationId;
    }

    public void setSpecializationId(int specializationId) {
        this.specializationId = specializationId;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public BigDecimal getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(BigDecimal monthlySalary) {
        this.monthlySalary = monthlySalary;
    }

    // Método toString() (opcional, para depuración)
    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", birthDate=" + birthDate +
                ", gender='" + gender + '\'' +
                ", rfc='" + rfc + '\'' +
                ", email='" + email + '\'' +
                ", addressId=" + addressId +
                ", departmentId=" + departmentId +
                ", buId=" + buId +
                ", jobPositionId=" + jobPositionId +
                ", specializationId=" + specializationId +
                ", hireDate=" + hireDate +
                ", monthlySalary=" + monthlySalary +
                '}';
    }
}
