package logica;

import java.math.BigDecimal;

public class StageService {

    private int projectId;
    private int stageId;
    private int serviceId;
    private String projectName;
    private String stageName;
    private String serviceName;
    private int hoursUsed;
    private BigDecimal serviceCost;

    // Constructor para insertar/actualizar
    public StageService(int projectId, int stageId, int serviceId, int hoursUsed, BigDecimal serviceCost) {
        this.projectId = projectId;
        this.stageId = stageId;
        this.serviceId = serviceId;
        this.hoursUsed = hoursUsed;
        this.serviceCost = serviceCost;
    }

    // Constructor para cargar datos
    public StageService(int projectId, String projectName, String stageName, String serviceName, int hoursUsed, BigDecimal serviceCost) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.stageName = stageName;
        this.serviceName = serviceName;
        this.hoursUsed = hoursUsed;
        this.serviceCost = serviceCost;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public int getStageId() {
        return stageId;
    }

    public void setStageId(int stageId) {
        this.stageId = stageId;
    }

    public int getServiceId() {
        return serviceId;
    }

    public void setServiceId(int serviceId) {
        this.serviceId = serviceId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public int getHoursUsed() {
        return hoursUsed;
    }

    public void setHoursUsed(int hoursUsed) {
        this.hoursUsed = hoursUsed;
    }

    public BigDecimal getServiceCost() {
        return serviceCost;
    }

    public void setServiceCost(BigDecimal serviceCost) {
        this.serviceCost = serviceCost;
    }

    
}
