package logica;

import java.math.BigDecimal;
import java.sql.Date;

public class Project {
    private int projectId;
    private String projectName;
    private String description;
    private int clientId;
    private String clientName;
    private java.sql.Date startDate;
    private java.sql.Date endDate;
     private String statusName; 
    private Integer addressId; 
    private BigDecimal estimatedTotalCost; 
    private BigDecimal totalCost; 


    public Project() {
    }

    public Project(int projectId, String projectName, String description, int clientId, String clientName, Date startDate,
                   Date endDate, String statusName, Integer addressId, BigDecimal estimatedTotalCost, BigDecimal totalCost) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.description = description;
        this.clientId = clientId;
         this.clientName = clientName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.statusName = statusName;
        this.addressId = addressId;
        this.estimatedTotalCost = estimatedTotalCost;
        this.totalCost = totalCost;
    }

    // Getters y Setters
    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public Integer getAddressId() {
        return addressId;
    }

    public void setAddressId(Integer addressId) {
        this.addressId = addressId;
    }

    public BigDecimal getEstimatedTotalCost() {
        return estimatedTotalCost;
    }

    public void setEstimatedTotalCost(BigDecimal estimatedTotalCost) {
        this.estimatedTotalCost = estimatedTotalCost;
    }

    public BigDecimal getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(BigDecimal totalCost) {
        this.totalCost = totalCost;
    }
    
     public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }


    @Override
    public String toString() {
        return "Project{" +
                "projectId=" + projectId +
                ", projectName='" + projectName + '\'' +
                ", description='" + description + '\'' +
                ", clientId=" + clientId +
                ", clientName=" + clientName +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", statusName=" + statusName +
                ", addressId=" + addressId +
                ", estimatedTotalCost=" + estimatedTotalCost +
                ", totalCost=" + totalCost +
                '}';
    }
}