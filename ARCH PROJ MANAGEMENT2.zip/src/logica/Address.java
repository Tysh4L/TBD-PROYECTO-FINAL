package logica;

public class Address {
    private int addressId;
    private String street;
    private String exteriorNumber;
    private String interiorNumber; 
    private String neighborhood;
    private String postalCode;
    private int cityId;

    public Address() {
    }

    public Address(int addressId, String street, String exteriorNumber, String interiorNumber, String neighborhood, String postalCode, int cityId) {
        this.addressId = addressId;
        this.street = street;
        this.exteriorNumber = exteriorNumber;
        this.interiorNumber = interiorNumber;
        this.neighborhood = neighborhood;
        this.postalCode = postalCode;
        this.cityId = cityId;
    }

    // Getters y Setters
    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getExteriorNumber() {
        return exteriorNumber;
    }

    public void setExteriorNumber(String exteriorNumber) {
        this.exteriorNumber = exteriorNumber;
    }

    public String getInteriorNumber() {
        return interiorNumber;
    }

    public void setInteriorNumber(String interiorNumber) {
        this.interiorNumber = interiorNumber;
    }

    public String getNeighborhood() {
        return neighborhood;
    }

    public void setNeighborhood(String neighborhood) {
        this.neighborhood = neighborhood;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public int getCityId() {
        return cityId;
    }

    public void setCityId(int cityId) {
        this.cityId = cityId;
    }

    @Override
    public String toString() {
        return "Address{" +
                "addressId=" + addressId +
                ", street='" + street + '\'' +
                ", exteriorNumber='" + exteriorNumber + '\'' +
                ", interiorNumber='" + (interiorNumber != null ? interiorNumber : "N/A") + '\'' +
                ", neighborhood='" + neighborhood + '\'' +
                ", postalCode='" + postalCode + '\'' +
                ", cityId=" + cityId +
                '}';
    }
}
