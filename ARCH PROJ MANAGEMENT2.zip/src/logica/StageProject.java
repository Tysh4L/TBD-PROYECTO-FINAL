package logica;

import java.sql.Date;

public class StageProject {
    private int projectId;
    private int stageId;
    private Date startDate;
    private Date dueDate;
    private int statusId;

    public StageProject(int projectId, int stageId, Date startDate, Date dueDate, int statusId) {
        this.projectId = projectId;
        this.stageId = stageId;
        this.startDate = startDate;
        this.dueDate = dueDate;
        this.statusId = statusId;
    }

    // Getters y Setters
    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public int getStageId() {
        return stageId;
    }

    public void setStageId(int stageId) {
        this.stageId = stageId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public int getStatusId() {
        return statusId;
    }

    public void setStatusId(int statusId) {
        this.statusId = statusId;
    }
}
