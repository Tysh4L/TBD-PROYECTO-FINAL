package logica;

public class BusinessUnit {
    private int businessUnitId;
    private String businessUnitName;

    public BusinessUnit(int businessUnitId, String businessUnitName) {
        this.businessUnitId = businessUnitId;
        this.businessUnitName = businessUnitName;
    }

    public int getBusinessUnitId() {
        return businessUnitId;
    }

    public void setBusinessUnitId(int businessUnitId) {
        this.businessUnitId = businessUnitId;
    }

    public String getBusinessUnitName() {
        return businessUnitName;
    }

    public void setBusinessUnitName(String businessUnitName) {
        this.businessUnitName = businessUnitName;
    }
}
