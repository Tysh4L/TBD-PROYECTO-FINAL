package logica;

import java.math.BigDecimal;
import java.util.Date;

public class EmployeePosition {
    private int positionId;
    private int employeeId;
    private int departmentId;
    private int buId; 
    private int jobPositionId; 
    private int specializationId; 
    private Date hireDate;
    private Date exitDate;
    private BigDecimal monthlySalary;

    public EmployeePosition() {
    }

    public EmployeePosition(int positionId, int employeeId, int departmentId, int buId, int jobPositionId, int specializationId, Date hireDate, Date exitDate, BigDecimal monthlySalary) {
        this.positionId = positionId;
        this.employeeId = employeeId;
        this.departmentId = departmentId;
        this.buId = buId;
        this.jobPositionId = jobPositionId;
        this.specializationId = specializationId;
        this.hireDate = hireDate;
        this.exitDate = exitDate;
        this.monthlySalary = monthlySalary;
    }

    // Getters y setters
    public int getPositionId() {
        return positionId;
    }

    public void setPositionId(int positionId) {
        this.positionId = positionId;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public int getBuId() {
        return buId;
    }

    public void setBuId(int buId) {
        this.buId = buId;
    }

    public int getJobPositionId() {
        return jobPositionId;
    }

    public void setJobPositionId(int jobPositionId) {
        this.jobPositionId = jobPositionId;
    }

    public int getSpecializationId() {
        return specializationId;
    }

    public void setSpecializationId(int specializationId) {
        this.specializationId = specializationId;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public Date getExitDate() {
        return exitDate;
    }

    public void setExitDate(Date exitDate) {
        this.exitDate = exitDate;
    }

    public BigDecimal getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(BigDecimal monthlySalary) {
        this.monthlySalary = monthlySalary;
    }

    @Override
    public String toString() {
        return "EmployeePosition{" +
                "positionId=" + positionId +
                ", employeeId=" + employeeId +
                ", departmentId=" + departmentId +
                ", buId=" + buId +
                ", jobPositionId=" + jobPositionId +
                ", specializationId=" + specializationId +
                ", hireDate=" + hireDate +
                ", exitDate=" + exitDate +
                ", monthlySalary=" + monthlySalary +
                '}';
    }
}
