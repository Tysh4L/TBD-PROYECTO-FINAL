package gui;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

import java.math.BigDecimal;
import java.util.List;
import javax.swing.JOptionPane;

import persistencia.DatabaseConnection;

import javax.swing.table.DefaultTableModel;

import logica.StageService;
import logica.StageSubcontractor;

import persistencia.StageServicesDAO;
import persistencia.StageSubcontractorDAO;

public class guiServicesSubcontractors extends javax.swing.JPanel {

    public guiServicesSubcontractors() {
        initComponents();
        addTableSelectionListener();
        addTableSelectionListenerSub();
        cargarServices();
        cargarSubcontractors();
        cargarProyectosSer();
        cargarProyectosSub();
        initializeTableModel();
        initializeSubcontractorsTableModel();
        loadStageServicesTable();
        loadSubcontractorsTable();
        cargarProyectosConServicios();
        cargarProyectosSubcontractor();

    }

    @SuppressWarnings("unchecked")

    private void limpiarCampos() {
        cbSubProject.setSelectedIndex(0);
        cbSelectSubProject.setSelectedIndex(0);
        cbSubStage.setSelectedIndex(0);
        cbSub.setSelectedIndex(0);
        txtHoursUsedSub.setText("");
        loadSubcontractorsTable();
        loadStageServicesTable();
        cbServiceProjectSearch.setSelectedIndex(0);
        cbSerProject.setSelectedIndex(0);
        cbSerStage.setSelectedIndex(0);
        cbService.setSelectedIndex(0);
        txtSerHoursUsed.setText("");
        habilitarCampos();

    }

    private void habilitarCampos() {
        cbSerProject.setEnabled(true);
        cbSerStage.setEnabled(true);
        cbService.setEnabled(true);

        cbSubProject.setEnabled(true);
        cbSubStage.setEnabled(true);
        cbSub.setEnabled(true);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbStage = new javax.swing.JLabel();
        jPanelSearch = new javax.swing.JPanel();
        lbProjectId2 = new javax.swing.JLabel();
        btnSearch2 = new javax.swing.JButton();
        cbSelectSubProject = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableSubcontractors = new javax.swing.JTable();
        btnClean = new javax.swing.JButton();
        jPanelSubcontractors = new javax.swing.JPanel();
        lbProject = new javax.swing.JLabel();
        lbStage1 = new javax.swing.JLabel();
        lbSub = new javax.swing.JLabel();
        lbHoursUsed = new javax.swing.JLabel();
        btnDelete2 = new javax.swing.JButton();
        btnUpdate2 = new javax.swing.JButton();
        btnSave2 = new javax.swing.JButton();
        cbSubProject = new javax.swing.JComboBox<>();
        cbSubStage = new javax.swing.JComboBox<>();
        cbSub = new javax.swing.JComboBox<>();
        txtHoursUsedSub = new javax.swing.JTextField();
        jPanelServices1 = new javax.swing.JPanel();
        lbProject1 = new javax.swing.JLabel();
        lbStage2 = new javax.swing.JLabel();
        lbService1 = new javax.swing.JLabel();
        lbHoursUsed1 = new javax.swing.JLabel();
        btnDelete1 = new javax.swing.JButton();
        btnUpdate1 = new javax.swing.JButton();
        btnSave1 = new javax.swing.JButton();
        cbSerProject = new javax.swing.JComboBox<>();
        cbSerStage = new javax.swing.JComboBox<>();
        cbService = new javax.swing.JComboBox<>();
        txtSerHoursUsed = new javax.swing.JTextField();
        jPanelSearch1 = new javax.swing.JPanel();
        lbProjectId3 = new javax.swing.JLabel();
        btnSearch1 = new javax.swing.JButton();
        cbServiceProjectSearch = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableServices = new javax.swing.JTable();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbStage.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        lbStage.setText("Services Subcontractors");
        add(lbStage, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 420, -1));

        lbProjectId2.setText("Project:");

        btnSearch2.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnSearch2.setText("Search");
        btnSearch2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearch2ActionPerformed(evt);
            }
        });

        cbSelectSubProject.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbSelectSubProject.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select project" }));
        cbSelectSubProject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSelectSubProjectActionPerformed(evt);
            }
        });

        jTableSubcontractors.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableSubcontractors);

        javax.swing.GroupLayout jPanelSearchLayout = new javax.swing.GroupLayout(jPanelSearch);
        jPanelSearch.setLayout(jPanelSearchLayout);
        jPanelSearchLayout.setHorizontalGroup(
            jPanelSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSearchLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanelSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelSearchLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanelSearchLayout.createSequentialGroup()
                        .addComponent(lbProjectId2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbSelectSubProject, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                        .addComponent(btnSearch2)
                        .addGap(73, 73, 73))))
        );
        jPanelSearchLayout.setVerticalGroup(
            jPanelSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSearchLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbProjectId2)
                    .addComponent(btnSearch2)
                    .addComponent(cbSelectSubProject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        add(jPanelSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 360, 350, 290));

        btnClean.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnClean.setText("Clean");
        btnClean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCleanActionPerformed(evt);
            }
        });
        add(btnClean, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 10, -1, -1));

        jPanelSubcontractors.setBorder(javax.swing.BorderFactory.createTitledBorder("Stage Subcontractors"));
        jPanelSubcontractors.setPreferredSize(new java.awt.Dimension(330, 580));

        lbProject.setText("Project:");

        lbStage1.setText("Stage:");

        lbSub.setText("Subcontractor:");

        lbHoursUsed.setText("Hours used:");

        btnDelete2.setText("Delete");
        btnDelete2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelete2ActionPerformed(evt);
            }
        });

        btnUpdate2.setText("Update");
        btnUpdate2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdate2ActionPerformed(evt);
            }
        });

        btnSave2.setText("Save");
        btnSave2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSave2ActionPerformed(evt);
            }
        });

        cbSubProject.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select project", " " }));
        cbSubProject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSubProjectActionPerformed(evt);
            }
        });

        cbSubStage.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select stage" }));

        cbSub.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select subcon", " " }));

        javax.swing.GroupLayout jPanelSubcontractorsLayout = new javax.swing.GroupLayout(jPanelSubcontractors);
        jPanelSubcontractors.setLayout(jPanelSubcontractorsLayout);
        jPanelSubcontractorsLayout.setHorizontalGroup(
            jPanelSubcontractorsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSubcontractorsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelSubcontractorsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanelSubcontractorsLayout.createSequentialGroup()
                        .addComponent(lbSub)
                        .addGap(18, 18, 18)
                        .addComponent(cbSub, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanelSubcontractorsLayout.createSequentialGroup()
                        .addComponent(lbHoursUsed)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtHoursUsedSub))
                    .addGroup(jPanelSubcontractorsLayout.createSequentialGroup()
                        .addComponent(btnDelete2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnUpdate2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSave2))
                    .addGroup(jPanelSubcontractorsLayout.createSequentialGroup()
                        .addGroup(jPanelSubcontractorsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbProject)
                            .addComponent(lbStage1))
                        .addGap(18, 18, 18)
                        .addGroup(jPanelSubcontractorsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbSubProject, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbSubStage, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(95, Short.MAX_VALUE))
        );
        jPanelSubcontractorsLayout.setVerticalGroup(
            jPanelSubcontractorsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSubcontractorsLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanelSubcontractorsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbProject)
                    .addComponent(cbSubProject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelSubcontractorsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbStage1)
                    .addComponent(cbSubStage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelSubcontractorsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbSub)
                    .addComponent(cbSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelSubcontractorsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbHoursUsed)
                    .addComponent(txtHoursUsedSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanelSubcontractorsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDelete2)
                    .addComponent(btnUpdate2)
                    .addComponent(btnSave2))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        add(jPanelSubcontractors, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 310, 250));

        jPanelServices1.setBorder(javax.swing.BorderFactory.createTitledBorder("Stage Service"));
        jPanelServices1.setPreferredSize(new java.awt.Dimension(330, 580));

        lbProject1.setText("Project:");

        lbStage2.setText("Stage:");

        lbService1.setText("Service:");

        lbHoursUsed1.setText("Hours used:");

        btnDelete1.setText("Delete");
        btnDelete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelete1ActionPerformed(evt);
            }
        });

        btnUpdate1.setText("Update");
        btnUpdate1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdate1ActionPerformed(evt);
            }
        });

        btnSave1.setText("Save");
        btnSave1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSave1ActionPerformed(evt);
            }
        });

        cbSerProject.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select project", " " }));
        cbSerProject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSerProjectActionPerformed(evt);
            }
        });

        cbSerStage.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select stage" }));

        cbService.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select service" }));

        javax.swing.GroupLayout jPanelServices1Layout = new javax.swing.GroupLayout(jPanelServices1);
        jPanelServices1.setLayout(jPanelServices1Layout);
        jPanelServices1Layout.setHorizontalGroup(
            jPanelServices1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelServices1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelServices1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanelServices1Layout.createSequentialGroup()
                        .addComponent(lbService1)
                        .addGap(18, 18, 18)
                        .addComponent(cbService, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanelServices1Layout.createSequentialGroup()
                        .addComponent(lbHoursUsed1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtSerHoursUsed))
                    .addGroup(jPanelServices1Layout.createSequentialGroup()
                        .addComponent(btnDelete1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnUpdate1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSave1))
                    .addGroup(jPanelServices1Layout.createSequentialGroup()
                        .addGroup(jPanelServices1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbProject1)
                            .addComponent(lbStage2))
                        .addGap(18, 18, 18)
                        .addGroup(jPanelServices1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbSerProject, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbSerStage, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(130, Short.MAX_VALUE))
        );
        jPanelServices1Layout.setVerticalGroup(
            jPanelServices1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelServices1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanelServices1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbProject1)
                    .addComponent(cbSerProject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelServices1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbStage2)
                    .addComponent(cbSerStage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelServices1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbService1)
                    .addComponent(cbService, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelServices1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbHoursUsed1)
                    .addComponent(txtSerHoursUsed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanelServices1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDelete1)
                    .addComponent(btnUpdate1)
                    .addComponent(btnSave1))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        add(jPanelServices1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 310, 250));

        lbProjectId3.setText("Project:");

        btnSearch1.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnSearch1.setText("Search");
        btnSearch1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearch1ActionPerformed(evt);
            }
        });

        cbServiceProjectSearch.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbServiceProjectSearch.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select project" }));
        cbServiceProjectSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbServiceProjectSearchActionPerformed(evt);
            }
        });

        jTableServices.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTableServices);

        javax.swing.GroupLayout jPanelSearch1Layout = new javax.swing.GroupLayout(jPanelSearch1);
        jPanelSearch1.setLayout(jPanelSearch1Layout);
        jPanelSearch1Layout.setHorizontalGroup(
            jPanelSearch1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSearch1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lbProjectId3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cbServiceProjectSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSearch1)
                .addGap(73, 73, 73))
            .addGroup(jPanelSearch1Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanelSearch1Layout.setVerticalGroup(
            jPanelSearch1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSearch1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelSearch1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbProjectId3)
                    .addComponent(btnSearch1)
                    .addComponent(cbServiceProjectSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        add(jPanelSearch1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 50, 320, 290));
    }// </editor-fold>//GEN-END:initComponents

    private Map<String, Integer> projectWithSubMap = new HashMap<>();

    private void cargarProyectosSubcontractor() {
        try {
            String query = "SELECT DISTINCT ss.project_id, p.project_name "
                    + "FROM stage_subcontractor ss "
                    + "JOIN project p ON ss.project_id = p.project_id "
                    + "ORDER BY ss.project_id";

            Connection conn = DatabaseConnection.getConnection();
            ResultSet resultSet = conn.createStatement().executeQuery(query);

            cbSelectSubProject.removeAllItems();
            projectWithSubMap.clear();

            cbSelectSubProject.addItem("Select project");

            while (resultSet.next()) {
                int projectId = resultSet.getInt("project_id");
                String projectName = resultSet.getString("project_name");
                String displayValue = projectId + " - " + projectName;

                cbSelectSubProject.addItem(displayValue);
                projectWithSubMap.put(displayValue, projectId);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading projects: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Map<String, Integer> projectSubMap = new HashMap<>();

    private void cargarProyectosSub() {
        try {
            String query = "SELECT DISTINCT sp.project_id, p.project_name "
                    + "FROM stage_project sp "
                    + "JOIN project p ON sp.project_id = p.project_id "
                    + "ORDER BY sp.project_id";
            Connection conn = DatabaseConnection.getConnection();
            ResultSet resultSet = conn.createStatement().executeQuery(query);

            cbSubProject.removeAllItems(); 
            projectSubMap.clear(); 

            cbSubProject.addItem("Select project");

            while (resultSet.next()) {
                int projectId = resultSet.getInt("project_id");
                String projectName = resultSet.getString("project_name");
                String displayValue = projectId + " - " + projectName;

                cbSubProject.addItem(displayValue);
                projectSubMap.put(displayValue, projectId);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading projects: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Map<String, Integer> stageSubMap = new HashMap<>();

    private void cargarStagesSub(int projectId) {
        try {
            String query = "SELECT sp.stage_id, s.stage_name "
                    + "FROM stage_project sp "
                    + "JOIN stage s ON sp.stage_id = s.stage_id "
                    + "WHERE sp.project_id = ?";
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, projectId);

            ResultSet resultSet = ps.executeQuery();

            cbSubStage.removeAllItems(); 
            stageSubMap.clear();

            cbSubStage.addItem("Select stage"); 

            while (resultSet.next()) {
                int stageId = resultSet.getInt("stage_id");
                String stageName = resultSet.getString("stage_name");

                cbSubStage.addItem(stageName);
                stageSubMap.put(stageName, stageId); 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading stages: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Map<String, Integer> subcontractorMap = new HashMap<>();

    private void cargarSubcontractors() {
        try {
            String query = "SELECT subcontractor_id, company_name FROM subcontractor ORDER BY company_name";
            Connection conn = DatabaseConnection.getConnection();
            ResultSet resultSet = conn.createStatement().executeQuery(query);

            cbSub.removeAllItems();
            subcontractorMap.clear();

            cbSub.addItem("Select subcontractor");

            while (resultSet.next()) {
                int subcontractorId = resultSet.getInt("subcontractor_id");
                String companyName = resultSet.getString("company_name");

                cbSub.addItem(companyName);
                subcontractorMap.put(companyName, subcontractorId);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading subcontractors: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void initializeSubcontractorsTableModel() {
        String[] columnNames = {
            "Project ID", "Project Name", "Stage Name", "Company Name", "Hours Used", "Subcontractor Cost"
        };

        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        jTableSubcontractors.setModel(tableModel);
    }

    private void loadSubcontractorsTable() {
        try {
            StageSubcontractorDAO dao = new StageSubcontractorDAO(DatabaseConnection.getConnection());
            List<StageSubcontractor> subcontractors = dao.getStageSubcontractor();

            DefaultTableModel model = (DefaultTableModel) jTableSubcontractors.getModel();
            model.setRowCount(0); 

            for (StageSubcontractor subcontractor : subcontractors) {
                model.addRow(new Object[]{
                    subcontractor.getProjectId(),
                    subcontractor.getProjectName(),
                    subcontractor.getStageName(),
                    subcontractor.getCompanyName(),
                    subcontractor.getHoursUsed(),
                    subcontractor.getSubcontractorCost()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading subcontractors data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void initializeTableModel() {
        String[] columnNames = {
            "Project ID", "Project Name", "Stage Name", "Service Name", "Hours Used", "Service Cost"
        };

        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        jTableServices.setModel(tableModel);
    }

    private void loadStageServicesTable() {
        try {
            StageServicesDAO dao = new StageServicesDAO(DatabaseConnection.getConnection());
            List<StageService> services = dao.getStageServices();

            DefaultTableModel model = (DefaultTableModel) jTableServices.getModel();
            model.setRowCount(0); 

            for (StageService service : services) {
                model.addRow(new Object[]{
                    service.getProjectId(),
                    service.getProjectName(),
                    service.getStageName(),
                    service.getServiceName(),
                    service.getHoursUsed(),
                    service.getServiceCost()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Map<String, Integer> projectSerMap = new HashMap<>();

    private void cargarProyectosSer() {
        try {
            String query = "SELECT DISTINCT sp.project_id, p.project_name "
                    + "FROM stage_project sp "
                    + "JOIN project p ON sp.project_id = p.project_id "
                    + "ORDER BY sp.project_id";
            Connection conn = DatabaseConnection.getConnection();
            ResultSet resultSet = conn.createStatement().executeQuery(query);

            cbSerProject.removeAllItems(); 
            projectSerMap.clear(); 

            cbSerProject.addItem("Select project"); 

            while (resultSet.next()) {
                int projectId = resultSet.getInt("project_id");
                String projectName = resultSet.getString("project_name");
                String displayValue = projectId + " - " + projectName;

                cbSerProject.addItem(displayValue);
                projectSerMap.put(displayValue, projectId); 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading projects: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Map<String, Integer> stageSerMap = new HashMap<>();

    private void cargarStagesSer(int projectId) {
        try {
            String query = "SELECT sp.stage_id, s.stage_name "
                    + "FROM stage_project sp "
                    + "JOIN stage s ON sp.stage_id = s.stage_id "
                    + "WHERE sp.project_id = ?";
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, projectId);

            ResultSet resultSet = ps.executeQuery();

            cbSerStage.removeAllItems(); 
            stageSerMap.clear(); 

            cbSerStage.addItem("Select stage"); 

            while (resultSet.next()) {
                int stageId = resultSet.getInt("stage_id");
                String stageName = resultSet.getString("stage_name");

                cbSerStage.addItem(stageName);
                stageSerMap.put(stageName, stageId); 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading stages: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Map<String, Integer> serviceMap = new HashMap<>();

    private void cargarServices() {
        try {
            String query = "SELECT service_id, service_name FROM services ORDER BY service_name";
            Connection conn = DatabaseConnection.getConnection();
            ResultSet resultSet = conn.createStatement().executeQuery(query);

            cbService.removeAllItems(); 
            serviceMap.clear(); 

            cbService.addItem("Select service"); 

            while (resultSet.next()) {
                int serviceId = resultSet.getInt("service_id");
                String serviceName = resultSet.getString("service_name");

                cbService.addItem(serviceName);
                serviceMap.put(serviceName, serviceId); 
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading services: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Map<String, Integer> projectWithServicesMap = new HashMap<>();

    private void cargarProyectosConServicios() {
        try {
            String query = "SELECT DISTINCT ss.project_id, p.project_name "
                    + "FROM stage_services ss "
                    + "JOIN project p ON ss.project_id = p.project_id "
                    + "ORDER BY ss.project_id";
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            cbServiceProjectSearch.removeAllItems();
            projectWithServicesMap.clear();

            cbServiceProjectSearch.addItem("Select project");

            while (rs.next()) {
                int projectId = rs.getInt("project_id");
                String projectName = rs.getString("project_name");
                String displayValue = projectId + " - " + projectName;

                cbServiceProjectSearch.addItem(displayValue);
                projectWithServicesMap.put(displayValue, projectId);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading projects with services: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void cargarDatosServiciosPorProyecto(int projectId) {
        try {
            String query = "SELECT ss.project_id, p.project_name, s.stage_name, ser.service_name, "
                    + "ss.hours_used, ss.service_cost "
                    + "FROM stage_services ss "
                    + "JOIN project p ON ss.project_id = p.project_id "
                    + "JOIN stage s ON ss.stage_id = s.stage_id "
                    + "JOIN services ser ON ss.service_id = ser.service_id "
                    + "WHERE ss.project_id = ?";
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, projectId);
            ResultSet rs = ps.executeQuery();

            DefaultTableModel model = (DefaultTableModel) jTableServices.getModel();
            model.setRowCount(0); 

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("project_id"),
                    rs.getString("project_name"),
                    rs.getString("stage_name"),
                    rs.getString("service_name"),
                    rs.getInt("hours_used"),
                    rs.getBigDecimal("service_cost")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading service data: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }


    private void btnCleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCleanActionPerformed
        // TODO add your handling code here:
        limpiarCampos();
    }//GEN-LAST:event_btnCleanActionPerformed

    private void cbSelectSubProjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSelectSubProjectActionPerformed
        String selectedProject = (String) cbSubProject.getSelectedItem();
        System.out.println("Proyecto seleccionado: " + selectedProject); // DEPURACIÓN
        System.out.println("Contenido del mapa projectSubMap: " + projectSubMap); // DEPURACIÓN

        if (selectedProject != null && !selectedProject.equals("Select project")) {
            Integer projectId = projectSubMap.get(selectedProject);
            System.out.println("ID del proyecto seleccionado: " + projectId); // DEPURACIÓN
            if (projectId != null) {
                cargarStagesSub(projectId);
            } else {
                System.out.println("No se encontró el ID del proyecto en el mapa."); // DEPURACIÓN
            }
        }
    }//GEN-LAST:event_cbSelectSubProjectActionPerformed

    private void btnSearch2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearch2ActionPerformed
        String selectedProject = (String) cbSelectSubProject.getSelectedItem();

        if (selectedProject == null || selectedProject.equals("Select project")) {
            JOptionPane.showMessageDialog(this, "Please select a project.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Integer projectId = projectSubMap.get(selectedProject);
        if (projectId == null) {
            JOptionPane.showMessageDialog(this, "Project not found in the map.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            String query = "SELECT ss.project_id, p.project_name, s.stage_name, sc.company_name, "
                    + "ss.hours_used, ss.subcontractor_cost "
                    + "FROM stage_subcontractor ss "
                    + "JOIN project p ON ss.project_id = p.project_id "
                    + "JOIN stage s ON ss.stage_id = s.stage_id "
                    + "JOIN subcontractor sc ON ss.subcontractor_id = sc.subcontractor_id "
                    + "WHERE ss.project_id = ?";

            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, projectId);
            ResultSet rs = ps.executeQuery();

            DefaultTableModel model = (DefaultTableModel) jTableSubcontractors.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("project_id"),
                    rs.getString("project_name"),
                    rs.getString("stage_name"),
                    rs.getString("company_name"),
                    rs.getInt("hours_used"),
                    rs.getBigDecimal("subcontractor_cost")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading subcontractor data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_btnSearch2ActionPerformed

    private void btnSearch1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearch1ActionPerformed
        String selectedProject = (String) cbServiceProjectSearch.getSelectedItem();

        if (selectedProject == null || selectedProject.equals("Select project")) {
            JOptionPane.showMessageDialog(this, "Please select a project.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Obtener el project_id del proyecto seleccionado
            int projectId = projectWithServicesMap.get(selectedProject);

            // Llamar al método para cargar los datos del proyecto
            cargarDatosServiciosPorProyecto(projectId);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnSearch1ActionPerformed

    private void cbServiceProjectSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbServiceProjectSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbServiceProjectSearchActionPerformed

    private void btnSave1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSave1ActionPerformed
        try {
            // Validar campos
            String selectedProject = (String) cbSerProject.getSelectedItem();
            String selectedStage = (String) cbSerStage.getSelectedItem();
            String selectedService = (String) cbService.getSelectedItem();
            String hoursUsedText = txtSerHoursUsed.getText();

            if (selectedProject == null || selectedStage == null || selectedService == null
                    || selectedProject.equals("Select project") || selectedStage.equals("Select stage")
                    || selectedService.equals("Select service") || hoursUsedText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int projectId = projectSerMap.get(selectedProject);
            int stageId = stageSerMap.get(selectedStage);
            int serviceId = serviceMap.get(selectedService);
            int hoursUsed = Integer.parseInt(hoursUsedText);

            // Crear un objeto StageService
            StageService service = new StageService(projectId, stageId, serviceId, hoursUsed, null);

            // Llamar al DAO para insertar
            StageServicesDAO dao = new StageServicesDAO(DatabaseConnection.getConnection());
            dao.insertStageService(service);

            JOptionPane.showMessageDialog(this, "Service added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

            // Actualizar la tabla y limpiar campos
            loadStageServicesTable();
            limpiarCampos();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid number for hours used.", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error adding service: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);

        }
    }//GEN-LAST:event_btnSave1ActionPerformed

    private void btnDelete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete1ActionPerformed
        try {
            int selectedRow = jTableServices.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Obtener los valores seleccionados de la tabla
            int projectId = (int) jTableServices.getValueAt(selectedRow, 0);
            int stageId = (int) jTableServices.getValueAt(selectedRow, 1);
            int serviceId = (int) jTableServices.getValueAt(selectedRow, 2);

            // Llamar al DAO para eliminar
            StageServicesDAO dao = new StageServicesDAO(DatabaseConnection.getConnection());
            dao.deleteStageService(projectId, stageId, serviceId);

            JOptionPane.showMessageDialog(this, "Service deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

            // Actualizar la tabla y limpiar campos
            loadStageServicesTable();
            limpiarCampos();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error deleting service: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnDelete1ActionPerformed

    private void cbSerProjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSerProjectActionPerformed
        String selectedProject = (String) cbSerProject.getSelectedItem();
        if (selectedProject != null && !selectedProject.equals("Select project")) {
            int projectId = projectSerMap.get(selectedProject);
            cargarStagesSer(projectId); // Carga las etapas asociadas al proyecto seleccionado
        }


    }//GEN-LAST:event_cbSerProjectActionPerformed

    private void btnUpdate1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdate1ActionPerformed
        try {
            int selectedRow = jTableServices.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a row to update.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Validar campos
            String selectedProject = (String) cbSerProject.getSelectedItem();
            String selectedStage = (String) cbSerStage.getSelectedItem();
            String selectedService = (String) cbService.getSelectedItem();
            String hoursUsedText = txtSerHoursUsed.getText();

            if (selectedProject == null || selectedStage == null || selectedService == null
                    || selectedProject.equals("Select project") || selectedStage.equals("Select stage")
                    || selectedService.equals("Select service") || hoursUsedText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int projectId = projectSerMap.get(selectedProject);
            int stageId = stageSerMap.get(selectedStage);
            int serviceId = serviceMap.get(selectedService);
            int hoursUsed = Integer.parseInt(hoursUsedText);

            // Crear un objeto StageService
            StageService service = new StageService(projectId, stageId, serviceId, hoursUsed, null);

            // Llamar al DAO para actualizar
            StageServicesDAO dao = new StageServicesDAO(DatabaseConnection.getConnection());
            dao.updateStageService(service);

            JOptionPane.showMessageDialog(this, "Service updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

            // Actualizar la tabla y limpiar campos
            loadStageServicesTable();
            limpiarCampos();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid number for hours used.", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating service: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnUpdate1ActionPerformed

    private void btnSave2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSave2ActionPerformed
        try {
            // Validar campos
            String selectedProject = (String) cbSubProject.getSelectedItem();
            String selectedStage = (String) cbSubStage.getSelectedItem();
            String selectedSubcontractor = (String) cbSub.getSelectedItem();
            String hoursUsedText = txtHoursUsedSub.getText();

            if (selectedProject == null || selectedStage == null || selectedSubcontractor == null
                    || selectedProject.equals("Select project") || selectedStage.equals("Select stage")
                    || selectedSubcontractor.equals("Select subcontractor") || hoursUsedText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int projectId = projectSubMap.get(selectedProject);
            int stageId = stageSubMap.get(selectedStage);
            int subcontractorId = subcontractorMap.get(selectedSubcontractor);
            int hoursUsed = Integer.parseInt(hoursUsedText);

            // Crear un objeto StageSubcontractor
            StageSubcontractor subcontractor = new StageSubcontractor(projectId, stageId, subcontractorId, hoursUsed, null);

            // Llamar al DAO para insertar
            StageSubcontractorDAO dao = new StageSubcontractorDAO(DatabaseConnection.getConnection());
            dao.insertStageSubcontractor(subcontractor);

            JOptionPane.showMessageDialog(this, "Subcontractor added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

            // Actualizar la tabla y limpiar campos
            loadSubcontractorsTable();
            limpiarCampos();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid number for hours used.", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error adding subcontractor: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_btnSave2ActionPerformed

    private void btnUpdate2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdate2ActionPerformed
        try {
            int selectedRow = jTableSubcontractors.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a row to update.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Validar campos
            String selectedProject = (String) cbSubProject.getSelectedItem();
            String selectedStage = (String) cbSubStage.getSelectedItem();
            String selectedSubcontractor = (String) cbSub.getSelectedItem();
            String hoursUsedText = txtHoursUsedSub.getText();

            if (selectedProject == null || selectedStage == null || selectedSubcontractor == null
                    || selectedProject.equals("Select project") || selectedStage.equals("Select stage")
                    || selectedSubcontractor.equals("Select subcontractor") || hoursUsedText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int projectId = projectSubMap.get(selectedProject);
            int stageId = stageSubMap.get(selectedStage);
            int subcontractorId = subcontractorMap.get(selectedSubcontractor);
            int hoursUsed = Integer.parseInt(hoursUsedText);

            // Crear un objeto StageSubcontractor
            StageSubcontractor subcontractor = new StageSubcontractor(projectId, stageId, subcontractorId, hoursUsed, null);

            // Llamar al DAO para actualizar
            StageSubcontractorDAO dao = new StageSubcontractorDAO(DatabaseConnection.getConnection());
            dao.updateStageSubcontractor(subcontractor);

            JOptionPane.showMessageDialog(this, "Subcontractor updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

            // Actualizar la tabla y limpiar campos
            loadSubcontractorsTable();
            limpiarCampos();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid number for hours used.", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating subcontractor: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnUpdate2ActionPerformed

    private void btnDelete2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete2ActionPerformed
        try {
            int selectedRow = jTableSubcontractors.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Obtener los valores seleccionados de la tabla
            String projectIdStr = jTableSubcontractors.getValueAt(selectedRow, 0).toString();
            String stageIdStr = jTableSubcontractors.getValueAt(selectedRow, 1).toString();
            String subcontractorIdStr = jTableSubcontractors.getValueAt(selectedRow, 2).toString();

            // Convertir los valores a Integer
            int projectId = Integer.parseInt(projectIdStr);
            int stageId = Integer.parseInt(stageIdStr);
            int subcontractorId = Integer.parseInt(subcontractorIdStr);

            // Llamar al DAO para eliminar
            StageSubcontractorDAO dao = new StageSubcontractorDAO(DatabaseConnection.getConnection());
            dao.deleteStageSubcontractor(projectId, stageId, subcontractorId);

            JOptionPane.showMessageDialog(this, "Subcontractor deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

            // Actualizar la tabla y limpiar campos
            loadSubcontractorsTable();
            limpiarCampos();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid data format. Ensure the selected row contains valid numeric IDs.", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error deleting subcontractor: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnDelete2ActionPerformed

    private void cbSubProjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSubProjectActionPerformed
        String selectedProject = (String) cbSubProject.getSelectedItem();
        System.out.println("Selected Project: " + selectedProject);
        System.out.println("Contenido de projectSubMap: " + projectSubMap); // DEPURACIÓN

        if (selectedProject != null && !selectedProject.equals("Select project")) {
            Integer projectId = projectSubMap.get(selectedProject);
            System.out.println("Project ID obtenido: " + projectId); // DEPURACIÓN
            if (projectId == null) {
                System.out.println("El projectId es null. Revisa el mapa o el ComboBox.");
            }
            cargarStagesSub(projectId);
        }
    }//GEN-LAST:event_cbSubProjectActionPerformed

    private void addTableSelectionListener() {
        jTableServices.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && jTableServices.getSelectedRow() != -1) {
                cargarDatosDesdeFilaSeleccionada();
            }
        });
    }

    private void cargarDatosDesdeFilaSeleccionada() {
        int selectedRow = jTableServices.getSelectedRow();
        if (selectedRow != -1) {
            DefaultTableModel model = (DefaultTableModel) jTableServices.getModel();

            // Extraer valores de la fila seleccionada
            int projectId = (int) model.getValueAt(selectedRow, 0); 
            String projectName = (String) model.getValueAt(selectedRow, 1); 
            String stageName = (String) model.getValueAt(selectedRow, 2); 
            String serviceName = (String) model.getValueAt(selectedRow, 3); 
            int hoursUsed = (int) model.getValueAt(selectedRow, 4); 
            BigDecimal serviceCost = (BigDecimal) model.getValueAt(selectedRow, 5); 

            // Llenar los campos
            cbSerProject.setSelectedItem(projectId + " - " + projectName); 
            cbSerStage.setSelectedItem(stageName);
            cbService.setSelectedItem(serviceName); 
            txtSerHoursUsed.setText(String.valueOf(hoursUsed)); 

            // Deshabilitar campos
            cbSerProject.setEnabled(false);
            cbSerStage.setEnabled(false);
            cbService.setEnabled(false);
        }
    }

    private void addTableSelectionListenerSub() {
        jTableSubcontractors.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && jTableSubcontractors.getSelectedRow() != -1) {
                cargarDatosDesdeFilaSeleccionadaSubcontractor();
            }
        });
    }

    private void cargarDatosDesdeFilaSeleccionadaSubcontractor() {
        int selectedRow = jTableSubcontractors.getSelectedRow();
        if (selectedRow != -1) {
            DefaultTableModel model = (DefaultTableModel) jTableSubcontractors.getModel();

            // Extraer valores de la fila seleccionada
            int projectId = (int) model.getValueAt(selectedRow, 0); 
            String projectName = (String) model.getValueAt(selectedRow, 1); 
            String stageName = (String) model.getValueAt(selectedRow, 2); 
            String companyName = (String) model.getValueAt(selectedRow, 3); 
            int hoursUsed = (int) model.getValueAt(selectedRow, 4); 

            // Llenar los campos
            txtHoursUsedSub.setText(String.valueOf(hoursUsed)); 

            // Seleccionar elementos en los ComboBox
            cbSubProject.setSelectedItem(projectId + " - " + projectName); 
            cbSubStage.setSelectedItem(stageName); 
            cbSub.setSelectedItem(companyName); 

            // Deshabilitar campos no editables si es necesario
            cbSubProject.setEnabled(false);
            cbSubStage.setEnabled(false);
            cbSub.setEnabled(false);
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClean;
    private javax.swing.JButton btnDelete1;
    private javax.swing.JButton btnDelete2;
    private javax.swing.JButton btnSave1;
    private javax.swing.JButton btnSave2;
    private javax.swing.JButton btnSearch1;
    private javax.swing.JButton btnSearch2;
    private javax.swing.JButton btnUpdate1;
    private javax.swing.JButton btnUpdate2;
    private javax.swing.JComboBox<String> cbSelectSubProject;
    private javax.swing.JComboBox<String> cbSerProject;
    private javax.swing.JComboBox<String> cbSerStage;
    private javax.swing.JComboBox<String> cbService;
    private javax.swing.JComboBox<String> cbServiceProjectSearch;
    private javax.swing.JComboBox<String> cbSub;
    private javax.swing.JComboBox<String> cbSubProject;
    private javax.swing.JComboBox<String> cbSubStage;
    private javax.swing.JPanel jPanelSearch;
    private javax.swing.JPanel jPanelSearch1;
    private javax.swing.JPanel jPanelServices1;
    private javax.swing.JPanel jPanelSubcontractors;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableServices;
    private javax.swing.JTable jTableSubcontractors;
    private javax.swing.JLabel lbHoursUsed;
    private javax.swing.JLabel lbHoursUsed1;
    private javax.swing.JLabel lbProject;
    private javax.swing.JLabel lbProject1;
    private javax.swing.JLabel lbProjectId2;
    private javax.swing.JLabel lbProjectId3;
    private javax.swing.JLabel lbService1;
    private javax.swing.JLabel lbStage;
    private javax.swing.JLabel lbStage1;
    private javax.swing.JLabel lbStage2;
    private javax.swing.JLabel lbSub;
    private javax.swing.JTextField txtHoursUsedSub;
    private javax.swing.JTextField txtSerHoursUsed;
    // End of variables declaration//GEN-END:variables
}
