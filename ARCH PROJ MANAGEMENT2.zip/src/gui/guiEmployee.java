package gui;

import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.awt.BorderLayout;
import java.math.BigDecimal;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import logica.City;
import persistencia.CityDAO;
import persistencia.ClientDAO;
import persistencia.DatabaseConnection;
import java.util.Date;
import javax.swing.JComboBox;
import logica.Client;
import logica.Address;
import logica.BusinessUnit;
import logica.Department;
import logica.Employee;
import logica.JobPosition;
import logica.Specialization;
import persistencia.BusinessUnitDAO;
import persistencia.DepartmentDAO;
import persistencia.EmployeeDAO;
import persistencia.JobPositionDAO;
import persistencia.SpecializationDAO;

public class guiEmployee extends javax.swing.JPanel {

    public guiEmployee() {
        initComponents();
        cargarCiudades();
        cargarDepartamentos();
        cargarBusinessUnits();
        cargarEspecializaciones();
        cargarJobPositions();
        cargarCiudades();
        txtRFC.setEditable(false);
        txtEmployeeId.setEditable(false);

        Employee_Table p = new Employee_Table();
        ShowPanel(p);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbEmployee = new javax.swing.JLabel();
        add_clients_btn = new javax.swing.JButton();
        Search_btn = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        gender_lb = new javax.swing.JLabel();
        cbGender = new javax.swing.JComboBox<>();
        txtLastName = new javax.swing.JTextField();
        last_name_lb = new javax.swing.JLabel();
        first_name_lb = new javax.swing.JLabel();
        txtFirstName = new javax.swing.JTextField();
        txtEmployeeId = new javax.swing.JTextField();
        client_id_lb = new javax.swing.JLabel();
        birthDatelb = new javax.swing.JLabel();
        jdcBirthDate = new com.toedter.calendar.JDateChooser();
        txtRFC = new javax.swing.JTextField();
        RFClb = new javax.swing.JLabel();
        email_lb = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        txtPhone = new javax.swing.JTextField();
        phone_number_lb = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        street_lb = new javax.swing.JLabel();
        txtInteriorNum = new javax.swing.JTextField();
        ext_num_lb = new javax.swing.JLabel();
        txtExteriorNum = new javax.swing.JTextField();
        txtStreet = new javax.swing.JTextField();
        int_num_lb = new javax.swing.JLabel();
        neigh_lb = new javax.swing.JLabel();
        txtNeighborhood = new javax.swing.JTextField();
        txtPostalCode = new javax.swing.JTextField();
        cbCity = new javax.swing.JComboBox<>();
        postal_code_lb = new javax.swing.JLabel();
        city_lb = new javax.swing.JLabel();
        lbEmployeeId = new javax.swing.JLabel();
        txtEmployeeIdSearch = new javax.swing.JTextField();
        btnClean = new javax.swing.JButton();
        tables = new javax.swing.JPanel();
        update_client_btn1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        lbDepartment = new javax.swing.JLabel();
        cbDepart = new javax.swing.JComboBox<>();
        lbBU = new javax.swing.JLabel();
        cbBU = new javax.swing.JComboBox<>();
        lbJP = new javax.swing.JLabel();
        cbJP = new javax.swing.JComboBox<>();
        cbSP = new javax.swing.JComboBox<>();
        lbSP = new javax.swing.JLabel();
        hireDate = new javax.swing.JLabel();
        jdcHireDate = new com.toedter.calendar.JDateChooser();
        phone_number_lb1 = new javax.swing.JLabel();
        txtMonthlySalary = new javax.swing.JTextField();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbEmployee.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        lbEmployee.setText("Employee");
        add(lbEmployee, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 190, -1));

        add_clients_btn.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        add_clients_btn.setText("Save");
        add_clients_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_clients_btnActionPerformed(evt);
            }
        });
        add(add_clients_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 70, 60, -1));

        Search_btn.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        Search_btn.setText("Search");
        Search_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Search_btnActionPerformed(evt);
            }
        });
        add(Search_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 220, 60, -1));

        btnDelete.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 130, 60, -1));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Add New Employee"));

        gender_lb.setText("Gender:");

        cbGender.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "F", "M" }));

        txtLastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLastNameActionPerformed(evt);
            }
        });

        last_name_lb.setText("Last name:");

        first_name_lb.setText("First name:");

        txtFirstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFirstNameActionPerformed(evt);
            }
        });

        txtEmployeeId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmployeeIdActionPerformed(evt);
            }
        });

        client_id_lb.setText("Employee id:");

        birthDatelb.setText("Birth date:");

        jdcBirthDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N

        txtRFC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRFCActionPerformed(evt);
            }
        });

        RFClb.setText("RFC:");

        email_lb.setText("Email:");

        txtEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailActionPerformed(evt);
            }
        });

        txtPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPhoneActionPerformed(evt);
            }
        });

        phone_number_lb.setText("Phone number:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(last_name_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))
                    .addComponent(first_name_lb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(client_id_lb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(phone_number_lb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(email_lb)
                            .addComponent(RFClb, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(birthDatelb, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(gender_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(cbGender, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(39, 39, 39))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtRFC, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                                    .addComponent(txtLastName, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                                    .addComponent(txtFirstName)
                                    .addComponent(txtEmployeeId))
                                .addGap(39, 39, 39))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jdcBirthDate, javax.swing.GroupLayout.DEFAULT_SIZE, 123, Short.MAX_VALUE)
                                .addGap(41, 41, 41)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtPhone, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)
                            .addComponent(txtEmail, javax.swing.GroupLayout.Alignment.LEADING))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(client_id_lb)
                    .addComponent(txtEmployeeId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(first_name_lb)
                    .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(last_name_lb)
                    .addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(birthDatelb)
                    .addComponent(jdcBirthDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RFClb)
                    .addComponent(txtRFC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbGender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gender_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email_lb)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phone_number_lb)
                    .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 240, 300));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Address"));

        street_lb.setText("Street:");

        ext_num_lb.setText("Exterior number:");

        int_num_lb.setText("Interior number:");

        neigh_lb.setText("Neighborhood:");

        cbCity.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbCity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbCityActionPerformed(evt);
            }
        });

        postal_code_lb.setText("Postal code:");

        city_lb.setText("City:");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ext_num_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(int_num_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(neigh_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(street_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(postal_code_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(city_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtStreet)
                    .addComponent(txtExteriorNum)
                    .addComponent(txtInteriorNum)
                    .addComponent(txtNeighborhood)
                    .addComponent(txtPostalCode)
                    .addComponent(cbCity, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtStreet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(street_lb)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtExteriorNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ext_num_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtInteriorNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(int_num_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNeighborhood, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(neigh_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPostalCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(postal_code_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(city_lb))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 50, -1, 220));

        lbEmployeeId.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        lbEmployeeId.setText("Employee id:");
        add(lbEmployeeId, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 160, -1, -1));

        txtEmployeeIdSearch.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        txtEmployeeIdSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmployeeIdSearchActionPerformed(evt);
            }
        });
        add(txtEmployeeIdSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 190, 60, -1));

        btnClean.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnClean.setText("Clean");
        btnClean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCleanActionPerformed(evt);
            }
        });
        add(btnClean, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 20, -1, -1));

        tables.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout tablesLayout = new javax.swing.GroupLayout(tables);
        tables.setLayout(tablesLayout);
        tablesLayout.setHorizontalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        tablesLayout.setVerticalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        add(tables, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 290, 390, 370));

        update_client_btn1.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        update_client_btn1.setText("Update");
        update_client_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_client_btn1ActionPerformed(evt);
            }
        });
        add(update_client_btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 100, 60, -1));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Job information"));

        lbDepartment.setText("Department:");

        cbDepart.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbDepart.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "F", "M" }));

        lbBU.setText("Business Unit:");

        cbBU.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbBU.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "F", "M" }));

        lbJP.setText("Job Position:");

        cbJP.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbJP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "F", "M" }));

        cbSP.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbSP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "F", "M" }));

        lbSP.setText("Specialization:");

        hireDate.setText("Hire Date:");

        jdcHireDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N

        phone_number_lb1.setText("Monthly Salary:");

        txtMonthlySalary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMonthlySalaryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbBU)
                            .addComponent(lbDepartment))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbDepart, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbBU, 0, 126, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lbJP)
                        .addGap(27, 27, 27)
                        .addComponent(cbJP, 0, 135, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lbSP)
                        .addGap(27, 27, 27)
                        .addComponent(cbSP, 0, 126, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(hireDate, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jdcHireDate, javax.swing.GroupLayout.DEFAULT_SIZE, 164, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(phone_number_lb1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtMonthlySalary, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbDepart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbDepartment))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbBU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbBU))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbJP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbJP))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbSP))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phone_number_lb1)
                    .addComponent(txtMonthlySalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(hireDate)
                    .addComponent(jdcHireDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34))
        );

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 250, 250));
    }// </editor-fold>//GEN-END:initComponents

    private void limpiarCampos() {
        txtEmployeeId.setText("");
        txtFirstName.setText("");
        txtLastName.setText("");
        txtRFC.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtMonthlySalary.setText("");
        jdcBirthDate.setDate(null);
        jdcHireDate.setDate(null);
        txtStreet.setText("");
        txtExteriorNum.setText("");
        txtInteriorNum.setText("");
        txtNeighborhood.setText("");
        txtPostalCode.setText("");
        txtEmployeeIdSearch.setText("");
        cbCity.setSelectedIndex(0);
        cbGender.setSelectedIndex(0);
        cbDepart.setSelectedIndex(0);
        cbBU.setSelectedIndex(0);
        cbCity.setSelectedIndex(0);
        cbJP.setSelectedIndex(0);
        cbSP.setSelectedIndex(0);

    }

    private void ShowPanel(JPanel p) {
        p.setSize(390, 370);
        p.setLocation(0, 0);

        tables.removeAll();
        tables.add(p, BorderLayout.CENTER);
        tables.revalidate();
        tables.repaint();
    }

    private Map<String, Integer> cityMap = new HashMap<>();

    private void cargarCiudades() {
        try {
            CityDAO cityDAO = new CityDAO(DatabaseConnection.getConnection());
            List<City> cities = cityDAO.getAllCities();

            cbCity.removeAllItems();
            cityMap.clear();

            cbCity.addItem("Select city");

            for (City city : cities) {
                cbCity.addItem(city.getCity_name());
                cityMap.put(city.getCity_name(), city.getCity_id());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private int getSelectedCityId() {
        String selectedCityName = (String) cbCity.getSelectedItem(); 

        if (cityMap.containsKey(selectedCityName)) {
            return cityMap.get(selectedCityName); 
        } else {
            throw new RuntimeException("City ID not found for: " + selectedCityName);
        }
    }

    private Map<String, Integer> departmentMap = new HashMap<>();

    private void cargarDepartamentos() {
        try {
            DepartmentDAO departmentDAO = new DepartmentDAO(DatabaseConnection.getConnection());
            List<Department> departments = departmentDAO.getAllDepartments();

            cbDepart.removeAllItems();
            departmentMap.clear();

            cbDepart.addItem("Select department");

            for (Department department : departments) {
                cbDepart.addItem(department.getDepartmentName());
                departmentMap.put(department.getDepartmentName(), department.getDepartmentId());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private int getSelectedDepartmentId() {
        String selectedDepartmentName = (String) cbDepart.getSelectedItem();

        if (departmentMap.containsKey(selectedDepartmentName)) {
            return departmentMap.get(selectedDepartmentName);
        } else {
            throw new RuntimeException("Department ID not found for: " + selectedDepartmentName);
        }
    }

    private Map<String, Integer> businessUnitMap = new HashMap<>();

    private void cargarBusinessUnits() {
        try {
            BusinessUnitDAO businessUnitDAO = new BusinessUnitDAO(DatabaseConnection.getConnection());
            List<BusinessUnit> businessUnits = businessUnitDAO.getAllBusinessUnits();

            cbBU.removeAllItems();
            businessUnitMap.clear();

            cbBU.addItem("Select business unit");

            for (BusinessUnit businessUnit : businessUnits) {
                cbBU.addItem(businessUnit.getBusinessUnitName());
                businessUnitMap.put(businessUnit.getBusinessUnitName(), businessUnit.getBusinessUnitId());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private int getSelectedBusinessUnitId() {
        String selectedBusinessUnitName = (String) cbBU.getSelectedItem();

        if (businessUnitMap.containsKey(selectedBusinessUnitName)) {
            return businessUnitMap.get(selectedBusinessUnitName);
        } else {
            throw new RuntimeException("Business Unit ID not found for: " + selectedBusinessUnitName);
        }
    }

    private Map<String, Integer> specializationMap = new HashMap<>();

    private void cargarEspecializaciones() {
        try {
            SpecializationDAO specializationDAO = new SpecializationDAO(DatabaseConnection.getConnection());
            List<Specialization> specializations = specializationDAO.getAllSpecializations();

            cbSP.removeAllItems();
            specializationMap.clear();

            cbSP.addItem("Select specialization");

            for (Specialization specialization : specializations) {
                cbSP.addItem(specialization.getSpecializationName());
                specializationMap.put(specialization.getSpecializationName(), specialization.getSpecializationId());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private int getSelectedSpecializationId() {
        String selectedSpecializationName = (String) cbSP.getSelectedItem();

        if (specializationMap.containsKey(selectedSpecializationName)) {
            return specializationMap.get(selectedSpecializationName);
        } else {
            throw new RuntimeException("Specialization ID not found for: " + selectedSpecializationName);
        }
    }

    private Map<String, Integer> jobPositionMap = new HashMap<>();

    private void cargarJobPositions() {
        try {
            JobPositionDAO jobPositionDAO = new JobPositionDAO(DatabaseConnection.getConnection());
            List<JobPosition> jobPositions = jobPositionDAO.getAllJobPositions();

            cbJP.removeAllItems();
            jobPositionMap.clear();

            cbJP.addItem("Select job position");

            for (JobPosition jobPosition : jobPositions) {
                cbJP.addItem(jobPosition.getJobPositionName());
                jobPositionMap.put(jobPosition.getJobPositionName(), jobPosition.getJobPositionId());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private int getSelectedJobPositionId() {
        String selectedJobPositionName = (String) cbJP.getSelectedItem();

        if (jobPositionMap.containsKey(selectedJobPositionName)) {
            return jobPositionMap.get(selectedJobPositionName);
        } else {
            throw new RuntimeException("Job Position ID not found for: " + selectedJobPositionName);
        }
    }

    private java.sql.Date getSqlDateFromChooser(JDateChooser dateChooser) {
        if (dateChooser.getDate() != null) {
            Date mBirthDate = dateChooser.getDate();
            long date = mBirthDate.getTime();
            return new java.sql.Date(date);
        } else {
            return null; 
        }
    }


    private void add_clients_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_clients_btnActionPerformed
        try {
            String firstName = txtFirstName.getText();
            String lastName = txtLastName.getText();
            Date birthDate = jdcBirthDate.getDate();
            String gender = (String) cbGender.getSelectedItem();
            int departmentId = cbDepart.getSelectedIndex();
            int buId = cbBU.getSelectedIndex();
            int jobPositionId = cbJP.getSelectedIndex();
            int specializationId = cbSP.getSelectedIndex();
            Date hireDate = jdcHireDate.getDate();
            String phoneNumbers = txtPhone.getText();
            BigDecimal monthlySalary = new BigDecimal(txtMonthlySalary.getText());
            String streetName = txtStreet.getText();
            String exteriorNum = txtExteriorNum.getText();
            String interiorNum = txtInteriorNum.getText();
            String neighborhoodName = txtNeighborhood.getText();
            String postalCode = txtPostalCode.getText();
            int cityId = cbCity.getSelectedIndex();

            // Llamar al DAO
            EmployeeDAO employeeDAO = new EmployeeDAO(DatabaseConnection.getConnection());
            employeeDAO.registerNewEmployee(
                    firstName, lastName, birthDate, gender,
                    departmentId, buId, jobPositionId, specializationId,
                    hireDate, phoneNumbers, monthlySalary,
                    streetName, exteriorNum, interiorNum,
                    neighborhoodName, postalCode, cityId
            );

            JOptionPane.showMessageDialog(this, "Empleado registrado exitosamente.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al registrar empleado: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_add_clients_btnActionPerformed

    private void Search_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Search_btnActionPerformed
        try {
            // Validar el ID del empleado
            String employeeIdText = txtEmployeeIdSearch.getText().trim();
            if (employeeIdText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El campo Employee ID no puede estar vacío.");
                return;
            }

            int employeeId = Integer.parseInt(employeeIdText);

            // Buscar los datos del empleado
            EmployeeDAO employeeDAO = new EmployeeDAO(DatabaseConnection.getConnection());
            Object[] employeeData = employeeDAO.getEmployeeData(employeeId);

            if (employeeData == null || employeeData[0] == null) {
                JOptionPane.showMessageDialog(this, "No se encontró un empleado con el ID especificado.");
                return;
            }

            Employee employee = (Employee) employeeData[0];
            Address address = (Address) employeeData[1];
            String phoneNumbers = (String) employeeData[2];
            String departmentName = (String) employeeData[3];
            String businessUnitName = (String) employeeData[4];
            String jobPositionName = (String) employeeData[5];
            String specializationName = (String) employeeData[6];

            // Llenar los campos del formulario
            txtEmployeeId.setText(String.valueOf(employee.getEmployeeId()));
            txtFirstName.setText(employee.getFirstName());
            txtLastName.setText(employee.getLastName());
            txtRFC.setText(employee.getRfc());
            txtEmail.setText(employee.getEmail());
            txtPhone.setText(phoneNumbers);
            cbGender.setSelectedItem(employee.getGender());
            txtStreet.setText(address.getStreet());
            txtExteriorNum.setText(address.getExteriorNumber());
            txtInteriorNum.setText(address.getInteriorNumber());
            txtNeighborhood.setText(address.getNeighborhood());
            txtPostalCode.setText(address.getPostalCode());

            jdcBirthDate.setDate(employee.getBirthDate());
            jdcHireDate.setDate(employee.getHireDate());
            txtMonthlySalary.setText(employee.getMonthlySalary().toString());

            setSelectedComboBox(cbCity, cityMap, address.getCityId());
            setSelectedComboBox(cbDepart, departmentMap, employee.getDepartmentId());
            setSelectedComboBox(cbBU, businessUnitMap, employee.getBuId());
            setSelectedComboBox(cbJP, jobPositionMap, employee.getJobPositionId());
            setSelectedComboBox(cbSP, specializationMap, employee.getSpecializationId());

            JOptionPane.showMessageDialog(this, "Empleado cargado correctamente.");
            Employee_Table p = new Employee_Table();
            ShowPanel(p);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al buscar el empleado: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_Search_btnActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        try {
            String employeeIdText = txtEmployeeIdSearch.getText().trim();
            if (employeeIdText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El campo Employee ID no puede estar vacío.");
                return;
            }

            int employeeId;
            try {
                employeeId = Integer.parseInt(employeeIdText);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Por favor, ingresa un número válido en el campo Employee ID.");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                    "¿Estás seguro de que deseas eliminar este empleado y todos sus datos asociados?",
                    "Confirmar eliminación",
                    JOptionPane.YES_NO_OPTION);

            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            // Llamar al DAO para eliminar el empleado
            EmployeeDAO employeeDAO = new EmployeeDAO(DatabaseConnection.getConnection());
            employeeDAO.deleteEmployee(employeeId);

            JOptionPane.showMessageDialog(this, "Empleado eliminado exitosamente.");
            Employee_Table p = new Employee_Table();
            ShowPanel(p);

            limpiarCampos();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al eliminar el empleado: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El ID del empleado debe ser un número válido.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void setSelectedComboBox(JComboBox<String> comboBox, Map<String, Integer> map, int id) {
        String name = null;
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue() == id) {
                name = entry.getKey();
                break;
            }
        }
        if (name != null) {
            comboBox.setSelectedItem(name);
        } else {
            comboBox.setSelectedIndex(0); 
        }
    }


    private void txtLastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLastNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLastNameActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void txtPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPhoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhoneActionPerformed

    private void txtEmployeeIdSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmployeeIdSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmployeeIdSearchActionPerformed

    private void txtFirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFirstNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFirstNameActionPerformed

    private void txtEmployeeIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmployeeIdActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_txtEmployeeIdActionPerformed

    private void btnCleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCleanActionPerformed
        // TODO add your handling code here:
        limpiarCampos();
    }//GEN-LAST:event_btnCleanActionPerformed

    private void cbCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCityActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_cbCityActionPerformed

    private void txtRFCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRFCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRFCActionPerformed

    private void update_client_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_client_btn1ActionPerformed
        try {
            // Capturar datos del formulario
            int employeeId = Integer.parseInt(txtEmployeeId.getText().trim());
            String firstName = txtFirstName.getText().trim();
            String lastName = txtLastName.getText().trim();
            java.sql.Date birthDateSQL = new java.sql.Date(jdcBirthDate.getDate().getTime());
            String gender = (String) cbGender.getSelectedItem();
            int departmentId = getSelectedDepartmentId();
            int buId = getSelectedBusinessUnitId();
            int jobPositionId = getSelectedJobPositionId();
            int specializationId = getSelectedSpecializationId();

            java.sql.Date hireDateSQL = new java.sql.Date(jdcHireDate.getDate().getTime());
            BigDecimal monthlySalary = new BigDecimal(txtMonthlySalary.getText().trim());
            String phone = txtPhone.getText().trim();
            String streetName = txtStreet.getText().trim();
            String exteriorNum = txtExteriorNum.getText().trim();
            String interiorNum = txtInteriorNum.getText().trim();
            String neighborhoodName = txtNeighborhood.getText().trim();
            String postalCode = txtPostalCode.getText().trim();
            int cityId = getSelectedCityId();

            // Validar campos obligatorios
            if (firstName.isEmpty() || lastName.isEmpty() || phone.isEmpty() || streetName.isEmpty()
                    || exteriorNum.isEmpty() || neighborhoodName.isEmpty() || postalCode.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.",
                        "Campos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Llamar al DAO para actualizar empleado y dirección
            EmployeeDAO employeeDAO = new EmployeeDAO(DatabaseConnection.getConnection());
            employeeDAO.updateEmployeeAndAddress(
                    employeeId, firstName, lastName, birthDateSQL, gender,
                    departmentId, buId, jobPositionId, specializationId,
                    hireDateSQL, monthlySalary, streetName, exteriorNum,
                    interiorNum, neighborhoodName, postalCode, cityId
            );

            // Obtener números telefónicos antiguos del empleado
            String[] newPhoneNumbers = phone.split(","); // Nuevos números
            String[] oldPhoneNumbers = getOldPhoneNumbers(employeeId); 

            // Eliminar números telefónicos que ya no están en el nuevo campo
            for (String oldPhone : oldPhoneNumbers) {
                boolean existsInNew = false;
                for (String newPhone : newPhoneNumbers) {
                    if (oldPhone.trim().equals(newPhone.trim())) {
                        existsInNew = true;
                        break;
                    }
                }
                if (!existsInNew) {
                    employeeDAO.deletePhone(employeeId, oldPhone.trim());
                }
            }

            // Insertar o actualizar números nuevos
            for (String newPhone : newPhoneNumbers) {
                boolean existsInOld = false;
                for (String oldPhone : oldPhoneNumbers) {
                    if (oldPhone.trim().equals(newPhone.trim())) {
                        existsInOld = true;
                        break;
                    }
                }
                if (!existsInOld) {
                    employeeDAO.updatePhone(employeeId, "", newPhone.trim());
                }
            }

            JOptionPane.showMessageDialog(this, "Empleado actualizado exitosamente.");
            Employee_Table p = new Employee_Table();
            ShowPanel(p);

            // Limpiar los campos
            limpiarCampos();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al actualizar el empleado: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID del empleado no válido.",
                    "Error", JOptionPane.WARNING_MESSAGE);
        }

    }//GEN-LAST:event_update_client_btn1ActionPerformed


    private void txtMonthlySalaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMonthlySalaryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMonthlySalaryActionPerformed

    private String[] getOldPhoneNumbers(int employeeId) throws SQLException {
        // Llamar al DAO para obtener los números telefónicos asociados al empleado
        EmployeeDAO employeeDAO = new EmployeeDAO(DatabaseConnection.getConnection());
        return employeeDAO.getEmployeePhoneNumbers(employeeId);
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel RFClb;
    private javax.swing.JButton Search_btn;
    private javax.swing.JButton add_clients_btn;
    private javax.swing.JLabel birthDatelb;
    private javax.swing.JButton btnClean;
    private javax.swing.JButton btnDelete;
    private javax.swing.JComboBox<String> cbBU;
    private javax.swing.JComboBox<String> cbCity;
    private javax.swing.JComboBox<String> cbDepart;
    private javax.swing.JComboBox<String> cbGender;
    private javax.swing.JComboBox<String> cbJP;
    private javax.swing.JComboBox<String> cbSP;
    private javax.swing.JLabel city_lb;
    private javax.swing.JLabel client_id_lb;
    private javax.swing.JLabel email_lb;
    private javax.swing.JLabel ext_num_lb;
    private javax.swing.JLabel first_name_lb;
    private javax.swing.JLabel gender_lb;
    private javax.swing.JLabel hireDate;
    private javax.swing.JLabel int_num_lb;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private com.toedter.calendar.JDateChooser jdcBirthDate;
    private com.toedter.calendar.JDateChooser jdcHireDate;
    private javax.swing.JLabel last_name_lb;
    private javax.swing.JLabel lbBU;
    private javax.swing.JLabel lbDepartment;
    private javax.swing.JLabel lbEmployee;
    private javax.swing.JLabel lbEmployeeId;
    private javax.swing.JLabel lbJP;
    private javax.swing.JLabel lbSP;
    private javax.swing.JLabel neigh_lb;
    private javax.swing.JLabel phone_number_lb;
    private javax.swing.JLabel phone_number_lb1;
    private javax.swing.JLabel postal_code_lb;
    private javax.swing.JLabel street_lb;
    private javax.swing.JPanel tables;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEmployeeId;
    private javax.swing.JTextField txtEmployeeIdSearch;
    private javax.swing.JTextField txtExteriorNum;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtInteriorNum;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextField txtMonthlySalary;
    private javax.swing.JTextField txtNeighborhood;
    private javax.swing.JTextField txtPhone;
    private javax.swing.JTextField txtPostalCode;
    private javax.swing.JTextField txtRFC;
    private javax.swing.JTextField txtStreet;
    private javax.swing.JButton update_client_btn1;
    // End of variables declaration//GEN-END:variables
}
