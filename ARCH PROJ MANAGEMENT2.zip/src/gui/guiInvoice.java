package gui;

import java.awt.BorderLayout;
import java.sql.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import persistencia.DatabaseConnection;
import persistencia.InvoiceDAO;
import persistencia.SessionManager;

public class guiInvoice extends javax.swing.JPanel {

    public guiInvoice() {
        initComponents();
        initializeClientInvoiceTableModel();
        initializeDetailsTableModel();
        cargarClientesEnComboBox();

        Invoice_Table p = new Invoice_Table();
        ShowPanel1(p);
    }

    @SuppressWarnings("unchecked")

    private void limpiarCampos() {
        cbClients.setSelectedIndex(0);
        DefaultTableModel clientInvoiceTableModel = (DefaultTableModel) tableClientInvoice.getModel();
        clientInvoiceTableModel.setRowCount(0);
        DefaultTableModel invoiceDetailsTableModel = (DefaultTableModel) tableInvoiceDetails.getModel();
        invoiceDetailsTableModel.setRowCount(0);

    }

    private void ShowPanel1(JPanel p) {
        p.setSize(670, 340);
        p.setLocation(0, 0);

        tables.removeAll();
        tables.add(p, BorderLayout.CENTER);
        tables.revalidate();
        tables.repaint();
    }

    private Map<Integer, String> clientMap = new HashMap<>(); // Relación ID -> Nombre

    private void cargarClientesEnComboBox() {
        try {
            String query = "SELECT inv.client_id, CONCAT(c.first_name, ' ', c.last_name) AS "
                    + "full_name FROM client c JOIN invoice inv ON c.client_id = inv.client_id;";
            ResultSet resultSet = DatabaseConnection.getConnection().createStatement().executeQuery(query);

            cbClients.removeAllItems(); 

            cbClients.addItem("Select client"); 

            while (resultSet.next()) {
                int id = resultSet.getInt("client_id");
                String fullName = resultSet.getString("full_name");
                String displayValue = id + " - " + fullName;

                cbClients.addItem(displayValue); 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private int getSelectedClientId() {
        String selectedClient = (String) cbClients.getSelectedItem(); 

        if (selectedClient == null || selectedClient.equals("Select client")) {
            return -1; 
        }

        try {
            String[] parts = selectedClient.split(" - "); 
            return Integer.parseInt(parts[0]); 
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return -1; 
        }
    }

    private void initializeClientInvoiceTableModel() {
        String[] columnNames = {
            "Invoice ID", "Client Name", "RFC", "Postal Code",
            "Project Name", "Stage Name", "Date Issued",
            "Subtotal", "Total", "CFDI Code"
        };

        DefaultTableModel clientInvoiceTableModel = new DefaultTableModel(columnNames, 0);
        tableClientInvoice.setModel(clientInvoiceTableModel);
    }

    private void updateClientInvoiceTable(List<String[]> invoices) {
        DefaultTableModel tableModel = (DefaultTableModel) tableClientInvoice.getModel();
        tableModel.setRowCount(0);

        for (String[] invoice : invoices) {
            tableModel.addRow(invoice);
        }
    }

    private void initializeDetailsTableModel() {
        String[] columnNames = {
            "Detail ID", "Invoice ID", "Reference ID", "Reference Type", "Hours Worked", "Total Cost"
        };

        DefaultTableModel detailTableModel = new DefaultTableModel(columnNames, 0);
        tableInvoiceDetails.setModel(detailTableModel);
    }

    private void updateInvoiceDetailsTable(List<String[]> details) {
        DefaultTableModel tableModel = (DefaultTableModel) tableInvoiceDetails.getModel();
        tableModel.setRowCount(0);

        for (String[] detail : details) {
            tableModel.addRow(detail);
        }
    }

    private void recargarTablas() {
        try {
            int clientId = getSelectedClientId();

            if (clientId == -1) {
                DefaultTableModel clientTableModel = (DefaultTableModel) tableClientInvoice.getModel();
                DefaultTableModel detailsTableModel = (DefaultTableModel) tableInvoiceDetails.getModel();
                clientTableModel.setRowCount(0);
                detailsTableModel.setRowCount(0);
                return;
            }

            InvoiceDAO invoiceDAO = new InvoiceDAO(DatabaseConnection.getConnection(SessionManager.getUsername(), SessionManager.getPassword()));
            List<String[]> invoices = invoiceDAO.getClientInvoices(clientId);
            updateClientInvoiceTable(invoices);

            if (!invoices.isEmpty()) {
                int firstInvoiceId = Integer.parseInt(invoices.get(0)[0]); 
                List<String[]> details = invoiceDAO.getInvoiceDetails(firstInvoiceId);
                updateInvoiceDetailsTable(details);
            } else {
                DefaultTableModel detailsTableModel = (DefaultTableModel) tableInvoiceDetails.getModel();
                detailsTableModel.setRowCount(0);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error while reloading tables: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tables1 = new javax.swing.JPanel();
        lbInvoice = new javax.swing.JLabel();
        btnClean = new javax.swing.JButton();
        tables = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnDelete = new javax.swing.JButton();
        btnSearch = new javax.swing.JButton();
        cbClients = new javax.swing.JComboBox<>();
        lbClient = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableClientInvoice = new javax.swing.JTable();
        tableInvDetailsPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableInvoiceDetails = new javax.swing.JTable();
        lbInvoiceDetails = new javax.swing.JLabel();
        lbInvoiceDetails1 = new javax.swing.JLabel();

        tables1.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout tables1Layout = new javax.swing.GroupLayout(tables1);
        tables1.setLayout(tables1Layout);
        tables1Layout.setHorizontalGroup(
            tables1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 680, Short.MAX_VALUE)
        );
        tables1Layout.setVerticalGroup(
            tables1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 528, Short.MAX_VALUE)
        );

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbInvoice.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        lbInvoice.setText("Invoices");
        add(lbInvoice, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 150, -1));

        btnClean.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnClean.setText("Clean");
        btnClean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCleanActionPerformed(evt);
            }
        });
        add(btnClean, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 20, -1, -1));

        tables.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout tablesLayout = new javax.swing.GroupLayout(tables);
        tables.setLayout(tablesLayout);
        tablesLayout.setHorizontalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 670, Short.MAX_VALUE)
        );
        tablesLayout.setVerticalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );

        add(tables, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 670, 340));

        btnDelete.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnSearch.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        cbClients.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select client", " " }));
        cbClients.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbClientsActionPerformed(evt);
            }
        });

        lbClient.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        lbClient.setText("Client:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lbClient)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cbClients, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 160, Short.MAX_VALUE)
                .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDelete)
                    .addComponent(btnSearch)
                    .addComponent(cbClients, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbClient))
                .addContainerGap())
        );

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 580, 40));

        tableClientInvoice.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tableClientInvoice);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 660, 70));

        tableInvoiceDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tableInvoiceDetails);

        lbInvoiceDetails.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        lbInvoiceDetails.setText("Invoice Details");

        javax.swing.GroupLayout tableInvDetailsPanelLayout = new javax.swing.GroupLayout(tableInvDetailsPanel);
        tableInvDetailsPanel.setLayout(tableInvDetailsPanelLayout);
        tableInvDetailsPanelLayout.setHorizontalGroup(
            tableInvDetailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tableInvDetailsPanelLayout.createSequentialGroup()
                .addComponent(lbInvoiceDetails)
                .addContainerGap(594, Short.MAX_VALUE))
            .addComponent(jScrollPane2)
        );
        tableInvDetailsPanelLayout.setVerticalGroup(
            tableInvDetailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tableInvDetailsPanelLayout.createSequentialGroup()
                .addComponent(lbInvoiceDetails)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        add(tableInvDetailsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 660, 120));

        lbInvoiceDetails1.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        lbInvoiceDetails1.setText("All invoices");
        add(lbInvoiceDetails1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));
    }// </editor-fold>//GEN-END:initComponents


    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        try {
            int clientId = getSelectedClientId();

            if (clientId == -1) {
                JOptionPane.showMessageDialog(this, "Please select a valid client.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Llamar al DAO para obtener las facturas del cliente
            InvoiceDAO invoiceDAO = new InvoiceDAO(DatabaseConnection.getConnection(SessionManager.getUsername(), SessionManager.getPassword()));
            List<String[]> invoices = invoiceDAO.getClientInvoices(clientId);

            // Actualizar la tabla con los resultados
            updateClientInvoiceTable(invoices);

            // Si hay facturas, obtener los detalles de la primera
            if (!invoices.isEmpty()) {
                int firstInvoiceId = Integer.parseInt(invoices.get(0)[0]); 
                List<String[]> details = invoiceDAO.getInvoiceDetails(firstInvoiceId);

                // Actualizar la tabla de detalles
                updateInvoiceDetailsTable(details);
            } else {
                // Limpiar la tabla de detalles si no hay facturas
                DefaultTableModel detailModel = (DefaultTableModel) tableInvoiceDetails.getModel();
                detailModel.setRowCount(0);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        try {
            // Verifica si hay una fila seleccionada en la tabla de clientInvoice
            int selectedRow = tableClientInvoice.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select an invoice to delete.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            DefaultTableModel tableModel = (DefaultTableModel) tableClientInvoice.getModel();
            int invoiceId = Integer.parseInt(tableModel.getValueAt(selectedRow, 0).toString()); // Invoice ID está en la primera columna

            // Confirmar antes de borrar
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this invoice?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            // Llamar al DAO para borrar la factura
            InvoiceDAO invoiceDAO = new InvoiceDAO(DatabaseConnection.getConnection(SessionManager.getUsername(), SessionManager.getPassword()));
            boolean deleted = invoiceDAO.deleteInvoice(invoiceId);

            if (deleted) {
                // Elimina la fila de la tabla visualmente
                tableModel.removeRow(selectedRow);
                Invoice_Table p = new Invoice_Table();
                ShowPanel1(p);
                JOptionPane.showMessageDialog(this, "Invoice deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete invoice.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            if (e.getMessage().contains("command denied")) {
                JOptionPane.showMessageDialog(this, "You don't have permission to delete invoices.", "Permission Denied", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "An unexpected error occurred. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btnDeleteActionPerformed


    private void btnCleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCleanActionPerformed
        limpiarCampos();
    }//GEN-LAST:event_btnCleanActionPerformed

    private void cbClientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbClientsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbClientsActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClean;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnSearch;
    private javax.swing.JComboBox<String> cbClients;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbClient;
    private javax.swing.JLabel lbInvoice;
    private javax.swing.JLabel lbInvoiceDetails;
    private javax.swing.JLabel lbInvoiceDetails1;
    private javax.swing.JTable tableClientInvoice;
    private javax.swing.JPanel tableInvDetailsPanel;
    private javax.swing.JTable tableInvoiceDetails;
    private javax.swing.JPanel tables;
    private javax.swing.JPanel tables1;
    // End of variables declaration//GEN-END:variables
}
