package gui;

import java.awt.BorderLayout;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import persistencia.BudgetDAO;
import persistencia.DatabaseConnection;

public class guiBudget extends javax.swing.JPanel {

    public guiBudget() {
        initComponents();
        txtBudgetId.setEditable(false);
        txtTotalServiceCost.setEditable(false);
        txtTotalSubcontractorCost.setEditable(false);
        txtTotalAmount.setEditable(false);
        cargarProyectosEnComboBox();

        Budget_Table p = new Budget_Table();
        ShowPanel(p);
    }

    @SuppressWarnings("unchecked")

    private void limpiarCampos() {
        txtBudgetId.setText("");
        txtBudgetId2.setText("");
        cbProject.setSelectedIndex(0);
        cbStage.setSelectedIndex(0);
        txtTotalServiceCost.setText("");
        txtTotalSubcontractorCost.setText("");
        txtTotalAmount.setText("");
    }

    private void ShowPanel(JPanel p) {
        p.setSize(680, 370);
        p.setLocation(0, 0);

        tables.removeAll();
        tables.add(p);
        tables.revalidate();
        tables.repaint();
    }

    private Map<String, Integer> projectMap = new HashMap<>();

    private void cargarProyectosEnComboBox() {
        try {
            String query = "SELECT DISTINCT sp.project_id, p.project_name FROM stage_project sp JOIN "
                    + "project p ON sp.project_id = p.project_id ORDER BY sp.project_id";
            Connection conn = DatabaseConnection.getConnection();
            ResultSet resultSet = conn.createStatement().executeQuery(query);

            cbProject.removeAllItems();
            projectMap.clear();

            cbProject.addItem("Select a project");

            while (resultSet.next()) {
                int id = resultSet.getInt("project_id");
                String name = resultSet.getString("project_name");
                String displayValue = id + " - " + name;

                cbProject.addItem(displayValue);
                projectMap.put(displayValue, id); 
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar los proyectos: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Map<String, Integer> stageMap = new HashMap<>();

    private void cargarEtapasDelProyecto(int projectId) {
        try {
            String query = "SELECT sp.stage_id, s.stage_name "
                    + "FROM stage_project sp "
                    + "INNER JOIN stage s ON sp.stage_id = s.stage_id "
                    + "WHERE sp.project_id = ?";
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, projectId);
            ps.setInt(1, projectId);

            ResultSet resultSet = ps.executeQuery();

            cbStage.removeAllItems();
            stageMap.clear();

            cbStage.addItem("Select a stage");

            while (resultSet.next()) {
                int stageId = resultSet.getInt("stage_id");
                String stageName = resultSet.getString("stage_name");

                cbStage.addItem(stageName);
                stageMap.put(stageName, stageId); // Relación texto -> ID
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar las etapas: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbBudget = new javax.swing.JLabel();
        btnAddBudget = new javax.swing.JButton();
        btnSearch = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        txtBudgetId = new javax.swing.JTextField();
        lbBudgetId = new javax.swing.JLabel();
        lbProject = new javax.swing.JLabel();
        lbStage = new javax.swing.JLabel();
        cbProject = new javax.swing.JComboBox<>();
        cbStage = new javax.swing.JComboBox<>();
        lbTotalAmount = new javax.swing.JLabel();
        txtTotalAmount = new javax.swing.JTextField();
        lbTotalSubcontractorCost = new javax.swing.JLabel();
        txtTotalSubcontractorCost = new javax.swing.JTextField();
        lbTotalServiceCost = new javax.swing.JLabel();
        txtTotalServiceCost = new javax.swing.JTextField();
        lbBudgetId2 = new javax.swing.JLabel();
        txtBudgetId2 = new javax.swing.JTextField();
        btnClean = new javax.swing.JButton();
        btnStageSubcontractors = new javax.swing.JButton();
        tables = new javax.swing.JPanel();
        btnBudgetTable = new javax.swing.JButton();
        btnStageServices1 = new javax.swing.JButton();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbBudget.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        lbBudget.setText("Budget");
        add(lbBudget, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 150, -1));

        btnAddBudget.setText("Add Budget");
        btnAddBudget.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddBudgetActionPerformed(evt);
            }
        });
        add(btnAddBudget, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 70, 120, -1));

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });
        add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 170, 120, -1));

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 100, 120, -1));

        txtBudgetId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBudgetIdActionPerformed(evt);
            }
        });

        lbBudgetId.setText("Budget id:");

        lbProject.setText("Project:");

        lbStage.setText("Stage:");

        cbProject.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbProject.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select project", " " }));
        cbProject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbProjectActionPerformed(evt);
            }
        });

        cbStage.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbStage.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select stage" }));
        cbStage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbStageActionPerformed(evt);
            }
        });

        lbTotalAmount.setText("Total amount:");

        lbTotalSubcontractorCost.setText("Total subcontractor cost:");

        lbTotalServiceCost.setText("Total service cost:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(lbBudgetId, javax.swing.GroupLayout.DEFAULT_SIZE, 153, Short.MAX_VALUE)
                        .addGap(351, 351, 351))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbStage, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbProject, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(78, 78, 78)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbStage, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cbProject, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtBudgetId)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lbTotalAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbTotalSubcontractorCost, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lbTotalServiceCost, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtTotalAmount)
                                    .addComponent(txtTotalSubcontractorCost)
                                    .addComponent(txtTotalServiceCost, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbBudgetId)
                    .addComponent(txtBudgetId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbProject)
                    .addComponent(cbProject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbStage)
                    .addComponent(cbStage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTotalAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbTotalAmount))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTotalSubcontractorCost, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbTotalSubcontractorCost))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTotalServiceCost, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbTotalServiceCost))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 510, 240));

        lbBudgetId2.setText("Budget id:");
        add(lbBudgetId2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 140, -1, -1));

        txtBudgetId2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBudgetId2ActionPerformed(evt);
            }
        });
        add(txtBudgetId2, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 140, 60, -1));

        btnClean.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnClean.setText("Clean");
        btnClean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCleanActionPerformed(evt);
            }
        });
        add(btnClean, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 20, -1, -1));

        btnStageSubcontractors.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnStageSubcontractors.setText("Stage Subcontractors");
        btnStageSubcontractors.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStageSubcontractorsActionPerformed(evt);
            }
        });
        add(btnStageSubcontractors, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 270, -1, -1));

        tables.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout tablesLayout = new javax.swing.GroupLayout(tables);
        tables.setLayout(tablesLayout);
        tablesLayout.setHorizontalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 680, Short.MAX_VALUE)
        );
        tablesLayout.setVerticalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );

        add(tables, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 680, 370));

        btnBudgetTable.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnBudgetTable.setText("Budgets");
        btnBudgetTable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBudgetTableActionPerformed(evt);
            }
        });
        add(btnBudgetTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 210, -1, -1));

        btnStageServices1.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnStageServices1.setText("Stage Services");
        btnStageServices1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStageServices1ActionPerformed(evt);
            }
        });
        add(btnStageServices1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 240, -1, -1));
    }// </editor-fold>//GEN-END:initComponents


    private void btnAddBudgetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddBudgetActionPerformed
        try {
            String selectedProject = (String) cbProject.getSelectedItem();
            String selectedStage = (String) cbStage.getSelectedItem();

            if (selectedProject == null || selectedStage == null || selectedProject.equals("Select a project") || selectedStage.equals("Select stage")) {
                JOptionPane.showMessageDialog(this, "Please select both a project and a stage.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return; 
            }

            // Obtener el project_id y stage_id desde los Map
            int projectId = projectMap.get(selectedProject);
            int stageId = stageMap.get(selectedStage);

            BudgetDAO budgetDAO = new BudgetDAO(DatabaseConnection.getConnection());
            boolean result = budgetDAO.addBudget(projectId, stageId);

            // Si el presupuesto se agrega exitosamente
            if (result) {
                JOptionPane.showMessageDialog(this, "Budget added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                limpiarCampos();
                Budget_Table p = new Budget_Table();
                ShowPanel(p);
            } else {
                // Si el presupuesto ya existe, el error se maneja en el DAO
                JOptionPane.showMessageDialog(this, "Error: A budget already exists for this project and stage.", "Duplicate Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
    
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error while adding the budget: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btnAddBudgetActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        try {
            String budgetId = txtBudgetId2.getText().trim();

            // Verificar que el Budget ID no esté vacío
            if (budgetId.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a Budget ID to search.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Consulta SQL para obtener el presupuesto
            String query = "SELECT b.budget_id, p.project_id, p.project_name, s.stage_id, s.stage_name, "
                    + "b.total_amount, b.total_subcontractor_cost, b.total_service_cost "
                    + "FROM budget b "
                    + "JOIN project p ON b.project_id = p.project_id "
                    + "JOIN stage s ON b.stage_id = s.stage_id "
                    + "WHERE b.budget_id = ?";

            Connection conn = DatabaseConnection.getConnection();  
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, Integer.parseInt(budgetId));  // Usar el Budget ID ingresado

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                // Obtener los valores del presupuesto
                String projectName = rs.getString("project_name");
                String stageName = rs.getString("stage_name");
                String totalAmount = rs.getString("total_amount");
                String totalSubcontractorCost = rs.getString("total_subcontractor_cost");
                String totalServiceCost = rs.getString("total_service_cost");

                // Obtener los ID correspondientes
                int projectId = rs.getInt("project_id");
                int stageId = rs.getInt("stage_id");

                // Llenar los campos con los datos obtenidos
                cbProject.setSelectedItem(projectId + " - " + projectName); 
                cbStage.setSelectedItem(stageName);  
                txtTotalAmount.setText(totalAmount);  
                txtTotalSubcontractorCost.setText(totalSubcontractorCost); 
                txtTotalServiceCost.setText(totalServiceCost); 
                txtBudgetId.setText(budgetId); 

     
                btnDelete.setEnabled(true);
            } else {
                
                JOptionPane.showMessageDialog(this, "Budget ID not found.", "Search Error", JOptionPane.ERROR_MESSAGE);
                btnDelete.setEnabled(false);  
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error while fetching the budget details: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        try {
            String selectedProject = (String) cbProject.getSelectedItem();
            String selectedStage = (String) cbStage.getSelectedItem();

            if (selectedProject == null || selectedStage == null || selectedProject.equals("Select a project") || selectedStage.equals("Select stage")) {
                JOptionPane.showMessageDialog(this, "Please select both a project and a stage to delete.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;  
            }

            // Obtener el project_id y stage_id desde los Map
            int projectId = projectMap.get(selectedProject);
            int stageId = stageMap.get(selectedStage);

            // Crear una instancia de BudgetDAO para eliminar el presupuesto
            BudgetDAO budgetDAO = new BudgetDAO(DatabaseConnection.getConnection());

            // Intentar eliminar el presupuesto
            boolean result = budgetDAO.deleteBudget(projectId, stageId);

            if (result) {
                JOptionPane.showMessageDialog(this, "Budget deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                limpiarCampos();  
            } else {
                JOptionPane.showMessageDialog(this, "Error: The budget for this project and stage could not be found or deleted.", "Delete Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error while deleting the budget: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btnDeleteActionPerformed


    private void txtBudgetId2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBudgetId2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBudgetId2ActionPerformed

    private void txtBudgetIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBudgetIdActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_txtBudgetIdActionPerformed

    private void btnCleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCleanActionPerformed
        limpiarCampos();
    }//GEN-LAST:event_btnCleanActionPerformed

    private void btnStageSubcontractorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStageSubcontractorsActionPerformed
        StageSubcontractor_Table p = new StageSubcontractor_Table();
        ShowPanel(p);
    }//GEN-LAST:event_btnStageSubcontractorsActionPerformed

    private void btnBudgetTableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBudgetTableActionPerformed
        Budget_Table p = new Budget_Table();
        ShowPanel(p);
    }//GEN-LAST:event_btnBudgetTableActionPerformed

    private void cbStageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbStageActionPerformed

    }//GEN-LAST:event_cbStageActionPerformed

    private void cbProjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbProjectActionPerformed
        String selectedProject = (String) cbProject.getSelectedItem();
        if (selectedProject != null && !selectedProject.equals("Select a project")) {
            int projectId = projectMap.get(selectedProject);
            cargarEtapasDelProyecto(projectId);
        }
    }//GEN-LAST:event_cbProjectActionPerformed

    private void btnStageServices1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStageServices1ActionPerformed
        StageServices_Table p = new StageServices_Table();
        ShowPanel(p);
    }//GEN-LAST:event_btnStageServices1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddBudget;
    private javax.swing.JButton btnBudgetTable;
    private javax.swing.JButton btnClean;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnStageServices1;
    private javax.swing.JButton btnStageSubcontractors;
    private javax.swing.JComboBox<String> cbProject;
    private javax.swing.JComboBox<String> cbStage;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lbBudget;
    private javax.swing.JLabel lbBudgetId;
    private javax.swing.JLabel lbBudgetId2;
    private javax.swing.JLabel lbProject;
    private javax.swing.JLabel lbStage;
    private javax.swing.JLabel lbTotalAmount;
    private javax.swing.JLabel lbTotalServiceCost;
    private javax.swing.JLabel lbTotalSubcontractorCost;
    private javax.swing.JPanel tables;
    private javax.swing.JTextField txtBudgetId;
    private javax.swing.JTextField txtBudgetId2;
    private javax.swing.JTextField txtTotalAmount;
    private javax.swing.JTextField txtTotalServiceCost;
    private javax.swing.JTextField txtTotalSubcontractorCost;
    // End of variables declaration//GEN-END:variables
}
