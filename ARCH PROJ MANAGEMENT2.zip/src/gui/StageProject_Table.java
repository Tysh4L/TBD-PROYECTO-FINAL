package gui;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import persistencia.DatabaseConnection;

public class StageProject_Table extends javax.swing.JPanel {

    public StageProject_Table() {
        initComponents();
        cargarStageProject();
    }

    @SuppressWarnings("unchecked")

    public void cargarStageProject() {
        try {
            String query = "SELECT sp.project_id, p.project_name, s.stage_name, sp.stage_id ,sp.start_date, sp.due_date, st.status_name\n"
                    + "FROM  stage_project sp\n"
                    + "JOIN project p ON sp.project_id = p.project_id\n"
                    + "JOIN stage s ON sp.stage_id = s.stage_id\n"
                    + "JOIN stage_status st ON sp.status_id = st.status_id ORDER BY sp.project_id";
            ResultSet resultSet = DatabaseConnection.getConnection()
                    .createStatement().executeQuery(query);

            // Crear modelo y asignarlo a la tabla
            DefaultTableModel model = buildTableModel(resultSet);
            tableStageProject.setModel(model);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar los datos de stage_project: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private DefaultTableModel buildTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();

        // Nombres de las columnas
        String[] columnNames = new String[columnCount];
        for (int i = 1; i <= columnCount; i++) {
            columnNames[i - 1] = metaData.getColumnName(i);
        }

        // Crear modelo de tabla personalizado
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Desactivar edición
            }
        };

        // Agregar las filas al modelo
        while (rs.next()) {
            Object[] row = new Object[columnCount];
            for (int i = 1; i <= columnCount; i++) {
                row[i - 1] = rs.getObject(i);
            }
            model.addRow(row);
        }

        return model;
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scrollPane = new javax.swing.JScrollPane();
        tableStageProject = new javax.swing.JTable();

        tableStageProject.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        scrollPane.setViewportView(tableStageProject);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 680, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 330, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JTable tableStageProject;
    // End of variables declaration//GEN-END:variables
}
