package gui;

import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.awt.BorderLayout;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import persistencia.DatabaseConnection;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import logica.Project;
import logica.Stage;
import logica.StageProject;
import logica.StageStatus;
import persistencia.ProjectDAO;
import persistencia.StageStatusDAO;
import persistencia.StageDAO;
import persistencia.StageProjectDAO;

public class guiStage extends javax.swing.JPanel {

    public guiStage() {
        initComponents();
        cargarProyectos();
        cargarStages();
        cargarStageStatus();
        cargarProyectosConStages();
        addTableSelectionListener();
        initializeStageProjectTableModel();

        StageProject_Table p = new StageProject_Table();
        ShowPanel(p);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbStage = new javax.swing.JLabel();
        jPanelStage = new javax.swing.JPanel();
        lbStage2 = new javax.swing.JLabel();
        lbProjec = new javax.swing.JLabel();
        lbStartDate = new javax.swing.JLabel();
        jdcStartDate = new com.toedter.calendar.JDateChooser();
        lbEndDate = new javax.swing.JLabel();
        jdcEndDate = new com.toedter.calendar.JDateChooser();
        cbProject = new javax.swing.JComboBox<>();
        cbStage = new javax.swing.JComboBox<>();
        lbStatus = new javax.swing.JLabel();
        cbStatus = new javax.swing.JComboBox<>();
        btnAddStage = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        tables = new javax.swing.JPanel();
        jPanelSearch = new javax.swing.JPanel();
        lbProjectId2 = new javax.swing.JLabel();
        btnSearch = new javax.swing.JButton();
        cbProject1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableStageProject = new javax.swing.JTable();
        btnClean = new javax.swing.JButton();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbStage.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        lbStage.setText("Stage");
        add(lbStage, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 113, -1));

        jPanelStage.setBorder(javax.swing.BorderFactory.createTitledBorder("Stage"));

        lbStage2.setText("Stage:");

        lbProjec.setText("Project:");

        lbStartDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        lbStartDate.setText("Start Date:");

        jdcStartDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N

        lbEndDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        lbEndDate.setText("End Date:");

        jdcEndDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N

        cbProject.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbProject.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select project" }));
        cbProject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbProjectActionPerformed(evt);
            }
        });

        cbStage.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbStage.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select stage" }));
        cbStage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbStageActionPerformed(evt);
            }
        });

        lbStatus.setText("Status:");

        cbStatus.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select status" }));

        btnAddStage.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnAddStage.setText("Save");
        btnAddStage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddStageActionPerformed(evt);
            }
        });

        btnUpdate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnDelete.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelStageLayout = new javax.swing.GroupLayout(jPanelStage);
        jPanelStage.setLayout(jPanelStageLayout);
        jPanelStageLayout.setHorizontalGroup(
            jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelStageLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanelStageLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnUpdate)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAddStage))
                    .addGroup(jPanelStageLayout.createSequentialGroup()
                        .addGroup(jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbStartDate, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbProjec)
                            .addComponent(lbStage2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbEndDate)
                            .addComponent(lbStatus))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbStatus, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jdcEndDate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jdcStartDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbStage, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanelStageLayout.createSequentialGroup()
                                .addComponent(cbProject, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(30, 30, 30))
        );
        jPanelStageLayout.setVerticalGroup(
            jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelStageLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbProjec)
                    .addComponent(cbProject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbStage2)
                    .addComponent(cbStage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbStartDate)
                    .addComponent(jdcStartDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jdcEndDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbEndDate, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbStatus)
                    .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanelStageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddStage)
                    .addComponent(btnUpdate)
                    .addComponent(btnDelete))
                .addGap(0, 14, Short.MAX_VALUE))
        );

        add(jPanelStage, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 330, 240));

        tables.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout tablesLayout = new javax.swing.GroupLayout(tables);
        tables.setLayout(tablesLayout);
        tablesLayout.setHorizontalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 680, Short.MAX_VALUE)
        );
        tablesLayout.setVerticalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 330, Short.MAX_VALUE)
        );

        add(tables, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 680, 330));

        lbProjectId2.setText("Project:");

        btnSearch.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        cbProject1.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbProject1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select project" }));
        cbProject1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbProject1ActionPerformed(evt);
            }
        });

        jTableStageProject.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableStageProject);

        javax.swing.GroupLayout jPanelSearchLayout = new javax.swing.GroupLayout(jPanelSearch);
        jPanelSearch.setLayout(jPanelSearchLayout);
        jPanelSearchLayout.setHorizontalGroup(
            jPanelSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSearchLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lbProjectId2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cbProject1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSearch)
                .addGap(73, 73, 73))
            .addGroup(jPanelSearchLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanelSearchLayout.setVerticalGroup(
            jPanelSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSearchLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbProjectId2)
                    .addComponent(btnSearch)
                    .addComponent(cbProject1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        add(jPanelSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 50, 320, 290));

        btnClean.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnClean.setText("Clean");
        btnClean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCleanActionPerformed(evt);
            }
        });
        add(btnClean, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 10, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void limpiarCampos() {
        jdcStartDate.setDate(null);
        jdcEndDate.setDate(null);
        cbProject.setSelectedIndex(0);
        cbProject1.setSelectedIndex(0);
        cbStage.setSelectedIndex(0);
        DefaultTableModel tableModel = (DefaultTableModel) jTableStageProject.getModel();
        tableModel.setRowCount(0);
        cbStatus.setSelectedIndex(0);
    }

    private void ShowPanel(JPanel p) {
        p.setSize(680, 330);
        p.setLocation(0, 0);

        tables.removeAll();
        tables.add(p, BorderLayout.CENTER);
        tables.revalidate();
        tables.repaint();
    }

    private java.sql.Date getSqlDateFromChooser(JDateChooser dateChooser) {
        if (dateChooser.getDate() != null) {
            Date mBirthDate = dateChooser.getDate();
            long date = mBirthDate.getTime();
            return new java.sql.Date(date);
        } else {
            return null; 
        }
    }

    private Map<String, Integer> projectMap = new HashMap<>();

    private void cargarProyectos() {
        try {
            ProjectDAO projectDAO = new ProjectDAO(DatabaseConnection.getConnection());
            List<Project> projects = projectDAO.getAllProjects();

            cbProject.removeAllItems();
            projectMap.clear();

            cbProject.addItem("Select project"); 

            for (Project project : projects) {
                String displayValue = project.getProjectId() + " - " + project.getProjectName(); 
                cbProject.addItem(displayValue); 
                projectMap.put(displayValue, project.getProjectId()); 
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading projects: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int getSelectedProjectId() {
        String selectedProject = (String) cbProject.getSelectedItem();

        if (projectMap.containsKey(selectedProject)) {
            return projectMap.get(selectedProject);
        } else {
            throw new RuntimeException("Project ID not found for: " + selectedProject);
        }
    }

    private Map<String, Integer> stageMap = new HashMap<>();

    private void cargarStages() {
        try {
            StageDAO stageDAO = new StageDAO(DatabaseConnection.getConnection());
            List<Stage> stages = stageDAO.getAllStages();

            cbStage.removeAllItems();
            stageMap.clear();

            cbStage.addItem("Select stage");

            for (Stage stage : stages) {
                cbStage.addItem(stage.getStage_name());
                stageMap.put(stage.getStage_name(), stage.getStage_id());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading stages: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private int getSelectedStageId() {
        String selectedStage = (String) cbStage.getSelectedItem();

        if (stageMap.containsKey(selectedStage)) {
            return stageMap.get(selectedStage);
        } else {
            throw new RuntimeException("Stage ID not found for: " + selectedStage);
        }
    }

    private Map<String, Integer> stageStatusMap = new HashMap<>();

    private void cargarStageStatus() {
        try {
            StageStatusDAO stageStatusDAO = new StageStatusDAO(DatabaseConnection.getConnection());
            List<StageStatus> stageStatuses = stageStatusDAO.getAllStageStatus();

            cbStatus.removeAllItems();
            stageStatusMap.clear();

            cbStatus.addItem("Select status");

            for (StageStatus status : stageStatuses) {
                cbStatus.addItem(status.getStatus_name());
                stageStatusMap.put(status.getStatus_name(), status.getStatus_id());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading stage statuses: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private int getSelectedStageStatusId() {
        String selectedStatusName = (String) cbStatus.getSelectedItem();

        if (stageStatusMap.containsKey(selectedStatusName)) {
            return stageStatusMap.get(selectedStatusName); 
        } else {
            throw new RuntimeException("Status ID not found for: " + selectedStatusName);
        }
    }

    private Map<String, Integer> projectMap1 = new HashMap<>();

    private void cargarProyectosConStages() {
        try {
            String query = "SELECT DISTINCT sp.project_id, p.project_name FROM stage_project sp JOIN "
                    + "project p ON sp.project_id = p.project_id ORDER BY sp.project_id";
            Connection conn = DatabaseConnection.getConnection();
            ResultSet resultSet = conn.createStatement().executeQuery(query);

            cbProject1.removeAllItems();
            projectMap1.clear();

            cbProject1.addItem("Select a project");

            while (resultSet.next()) {
                int id = resultSet.getInt("project_id");
                String name = resultSet.getString("project_name");
                String displayValue = id + " - " + name;

                cbProject1.addItem(displayValue);
                projectMap1.put(displayValue, id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar los proyectos: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int getSelectedProjectId2() {
        String selectedProject = (String) cbProject1.getSelectedItem();

        if (selectedProject == null || selectedProject.equals("Select a project")) {
            return -1;
        }

        try {
            String[] parts = selectedProject.split(" - ");
            return Integer.parseInt(parts[0]);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return -1;
        }
    }

    private void updateStageProjectTable(int projectId) {
        try {
            String query = "SELECT sp.project_id, p.project_name, s.stage_name, sp.stage_id, sp.start_date, sp.due_date, st.status_name "
                    + "FROM stage_project sp "
                    + "JOIN project p ON sp.project_id = p.project_id "
                    + "JOIN stage s ON sp.stage_id = s.stage_id "
                    + "JOIN stage_status st ON sp.status_id = st.status_id "
                    + "WHERE sp.project_id = ?";

            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, projectId); 
            ResultSet resultSet = stmt.executeQuery();

            DefaultTableModel tableModel = (DefaultTableModel) jTableStageProject.getModel();
            tableModel.setRowCount(0); 

            while (resultSet.next()) {
                int projectIdValue = resultSet.getInt("project_id");
                String projectName = resultSet.getString("project_name");
                String stageName = resultSet.getString("stage_name");
                int stageId = resultSet.getInt("stage_id");
                Date startDate = resultSet.getDate("start_date");
                Date dueDate = resultSet.getDate("due_date");
                String statusName = resultSet.getString("status_name");

                tableModel.addRow(new Object[]{projectIdValue, projectName, stageName, stageId, startDate, dueDate, statusName});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading stage projects: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void addTableSelectionListener() {
        jTableStageProject.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarDatosDesdeFilaSeleccionada();
            }
        });
    }

    private void cargarDatosDesdeFilaSeleccionada() {
        int selectedRow = jTableStageProject.getSelectedRow();
        if (selectedRow != -1) {
            DefaultTableModel tableModel = (DefaultTableModel) jTableStageProject.getModel();

            int projectId = (int) tableModel.getValueAt(selectedRow, 0); 
            String projectName = (String) tableModel.getValueAt(selectedRow, 1); 
            String stageName = (String) tableModel.getValueAt(selectedRow, 2); 
            Date startDate = (Date) tableModel.getValueAt(selectedRow, 4); 
            Date dueDate = (Date) tableModel.getValueAt(selectedRow, 5); 
            String statusName = (String) tableModel.getValueAt(selectedRow, 6); 

            for (int i = 0; i < cbProject.getItemCount(); i++) {
                String item = (String) cbProject.getItemAt(i);
                if (item.startsWith(projectId + " -")) {
                    cbProject.setSelectedIndex(i);
                    break;
                }
            }

            cbStage.setSelectedItem(stageName);
            cbStatus.setSelectedItem(statusName);

            jdcStartDate.setDate(startDate);
            jdcEndDate.setDate(dueDate);
        }
    }

    private void actualizarStageProject() {
        try {
            int projectId = getSelectedProjectId(); 
            int stageId = getSelectedStageId(); 
            Date startDate = jdcStartDate.getDate();
            Date dueDate = jdcEndDate.getDate();
            int statusId = getSelectedStageStatusId(); 

            if (projectId == -1 || stageId == -1 || startDate == null || dueDate == null || statusId == -1) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Connection conn = DatabaseConnection.getConnection();
            CallableStatement stmt = conn.prepareCall("{CALL UpdateStageProject(?, ?, ?, ?, ?)}");
            stmt.setInt(1, projectId);
            stmt.setInt(2, stageId);
            stmt.setDate(3, new java.sql.Date(startDate.getTime()));
            stmt.setDate(4, new java.sql.Date(dueDate.getTime()));
            stmt.setInt(5, statusId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Stage project updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                updateStageProjectTable(projectId);

            } else {
                JOptionPane.showMessageDialog(this, "No rows were updated.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating stage project: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void initializeStageProjectTableModel() {
        String[] columnNames = {
            "Project ID", "Project Name", "Stage Name", "Stage ID", "Start Date", "Due Date", "Status Name"
        };

        DefaultTableModel stageProjectTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        jTableStageProject.setModel(stageProjectTableModel);
    }


    private void btnAddStageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddStageActionPerformed
        try {
            int projectId = getSelectedProjectId();
            int stageId = getSelectedStageId();
            int statusId = getSelectedStageStatusId();
            java.sql.Date startDate = getSqlDateFromChooser(jdcStartDate);
            java.sql.Date endDate = getSqlDateFromChooser(jdcEndDate);

            if (projectId == -1 || stageId == -1 || statusId == -1 || startDate == null || endDate == null) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            StageProject stageProject = new StageProject(projectId, stageId, startDate, endDate, statusId);

            StageProjectDAO stageProjectDAO = new StageProjectDAO(DatabaseConnection.getConnection());
            stageProjectDAO.insertStageProject(stageProject);

            JOptionPane.showMessageDialog(this, "Stage successfully added to the project.", "Success", JOptionPane.INFORMATION_MESSAGE);
            limpiarCampos();
            StageProject_Table p = new StageProject_Table();
            ShowPanel(p);
            updateStageProjectTable(projectId);

        } catch (SQLException e) {
            if (e.getSQLState().equals("23000")) {
                JOptionPane.showMessageDialog(this, "This stage is already assigned to the selected project.", "Duplicate Entry", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Error saving stage project: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnAddStageActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        int selectedRow = jTableStageProject.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            DefaultTableModel tableModel = (DefaultTableModel) jTableStageProject.getModel();
            int projectId = (int) tableModel.getValueAt(selectedRow, 0); 
            int stageId = (int) tableModel.getValueAt(selectedRow, 3); 

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this stage from the project?",
                    "Confirm Delete",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                StageProjectDAO stageProjectDAO = new StageProjectDAO(DatabaseConnection.getConnection());
                boolean isDeleted = stageProjectDAO.deleteStageProject(projectId, stageId);

                if (isDeleted) {
                    JOptionPane.showMessageDialog(this, "Stage successfully deleted.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    updateStageProjectTable(projectId); 
                } else {
                    JOptionPane.showMessageDialog(this, "Error: Stage not found or could not be deleted.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error deleting stage project: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnDeleteActionPerformed


    private void btnCleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCleanActionPerformed
        // TODO add your handling code here:
        limpiarCampos();
    }//GEN-LAST:event_btnCleanActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        try {
            int projectId = getSelectedProjectId();
            int stageId = getSelectedStageId();
            int statusId = getSelectedStageStatusId();
            java.sql.Date startDate = getSqlDateFromChooser(jdcStartDate);
            java.sql.Date endDate = getSqlDateFromChooser(jdcEndDate);

            if (projectId == -1 || stageId == -1 || statusId == -1 || startDate == null || endDate == null) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            StageProject stageProject = new StageProject(projectId, stageId, startDate, endDate, statusId);

            StageProjectDAO stageProjectDAO = new StageProjectDAO(DatabaseConnection.getConnection());
            stageProjectDAO.updateStageProject(stageProject);

            JOptionPane.showMessageDialog(this, "Stage project updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            StageProject_Table p = new StageProject_Table();
            ShowPanel(p);
            
            updateStageProjectTable(projectId);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating stage project: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnUpdateActionPerformed

    private void cbProjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbProjectActionPerformed

    }//GEN-LAST:event_cbProjectActionPerformed

    private void cbStageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbStageActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbStageActionPerformed

    private void cbProject1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbProject1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbProject1ActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        try {
            int projectId = getSelectedProjectId2();
            if (projectId == -1) {
                JOptionPane.showMessageDialog(this, "Please select a project.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            updateStageProjectTable(projectId);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error searching project: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_btnSearchActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddStage;
    private javax.swing.JButton btnClean;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cbProject;
    private javax.swing.JComboBox<String> cbProject1;
    private javax.swing.JComboBox<String> cbStage;
    private javax.swing.JComboBox<String> cbStatus;
    private javax.swing.JPanel jPanelSearch;
    private javax.swing.JPanel jPanelStage;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableStageProject;
    private com.toedter.calendar.JDateChooser jdcEndDate;
    private com.toedter.calendar.JDateChooser jdcStartDate;
    private javax.swing.JLabel lbEndDate;
    private javax.swing.JLabel lbProjec;
    private javax.swing.JLabel lbProjectId2;
    private javax.swing.JLabel lbStage;
    private javax.swing.JLabel lbStage2;
    private javax.swing.JLabel lbStartDate;
    private javax.swing.JLabel lbStatus;
    private javax.swing.JPanel tables;
    // End of variables declaration//GEN-END:variables
}
