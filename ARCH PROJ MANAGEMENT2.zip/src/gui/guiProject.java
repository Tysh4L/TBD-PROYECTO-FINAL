package gui;

import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.awt.BorderLayout;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import logica.City;
import persistencia.CityDAO;
import persistencia.DatabaseConnection;
import java.util.Date;
import logica.Address;
import logica.Project;
import persistencia.ProjectDAO;

public class guiProject extends javax.swing.JPanel {

    public guiProject() {
        initComponents();
        cargarCiudades();
        cargarClientesEnComboBox();
        cargarStatus();
        txtProjectId.setEditable(false);

        Project_Table p = new Project_Table();
        ShowPanel(p);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbProject = new javax.swing.JLabel();
        btnAddProject = new javax.swing.JButton();
        btnSearch = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        lbDescription = new javax.swing.JLabel();
        lbProjectName = new javax.swing.JLabel();
        txtNameProject = new javax.swing.JTextField();
        txtProjectId = new javax.swing.JTextField();
        lbProjectId = new javax.swing.JLabel();
        lbStartDate = new javax.swing.JLabel();
        jdcStartDate = new com.toedter.calendar.JDateChooser();
        lbEndDate = new javax.swing.JLabel();
        jdcEndDate = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtADescProject = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        street_lb = new javax.swing.JLabel();
        txtInteriorNum = new javax.swing.JTextField();
        ext_num_lb = new javax.swing.JLabel();
        txtExteriorNum = new javax.swing.JTextField();
        txtStreet = new javax.swing.JTextField();
        int_num_lb = new javax.swing.JLabel();
        neigh_lb = new javax.swing.JLabel();
        txtNeighborhood = new javax.swing.JTextField();
        txtPostalCode = new javax.swing.JTextField();
        cbCity = new javax.swing.JComboBox<>();
        postal_code_lb = new javax.swing.JLabel();
        city_lb = new javax.swing.JLabel();
        lbClientId = new javax.swing.JLabel();
        lbStatus = new javax.swing.JLabel();
        cbStatus = new javax.swing.JComboBox<>();
        cbClients = new javax.swing.JComboBox<>();
        lbProjectId2 = new javax.swing.JLabel();
        txtProjectId2 = new javax.swing.JTextField();
        btnClean = new javax.swing.JButton();
        btnAddressTable = new javax.swing.JButton();
        tables = new javax.swing.JPanel();
        btnProjectTable = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbProject.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        lbProject.setText("Project");
        add(lbProject, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 113, -1));

        btnAddProject.setText("Add Project");
        btnAddProject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddProjectActionPerformed(evt);
            }
        });
        add(btnAddProject, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 70, 120, -1));

        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });
        add(btnSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 200, 120, -1));

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 130, 120, -1));

        lbDescription.setText("Description:");

        lbProjectName.setText("Name:");

        txtNameProject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameProjectActionPerformed(evt);
            }
        });

        txtProjectId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProjectIdActionPerformed(evt);
            }
        });

        lbProjectId.setText("Project id:");

        lbStartDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        lbStartDate.setText("Start Date:");

        jdcStartDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N

        lbEndDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        lbEndDate.setText("End Date:");

        jdcEndDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N

        txtADescProject.setColumns(20);
        txtADescProject.setRows(5);
        jScrollPane1.setViewportView(txtADescProject);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbProjectName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbProjectId, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbStartDate, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbEndDate, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtNameProject)
                            .addComponent(txtProjectId)
                            .addComponent(jdcStartDate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE)
                            .addComponent(jdcEndDate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(39, 39, 39))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(31, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(lbDescription, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbProjectId)
                    .addComponent(txtProjectId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbProjectName)
                    .addComponent(txtNameProject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbDescription)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbStartDate)
                    .addComponent(jdcStartDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jdcEndDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbEndDate, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25))
        );

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 240, 270));

        street_lb.setText("Street:");

        ext_num_lb.setText("Exterior number:");

        int_num_lb.setText("Interior number:");

        neigh_lb.setText("Neighborhood:");

        cbCity.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbCity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbCityActionPerformed(evt);
            }
        });

        postal_code_lb.setText("Postal code:");

        city_lb.setText("City:");

        lbClientId.setText("Client:");

        lbStatus.setText("Status:");

        cbStatus.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "F", "M" }));

        cbClients.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbClients.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbClients.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbClientsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(ext_num_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(int_num_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(neigh_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(street_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(postal_code_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(city_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbClientId, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtStreet)
                    .addComponent(txtExteriorNum)
                    .addComponent(txtInteriorNum)
                    .addComponent(txtNeighborhood)
                    .addComponent(txtPostalCode)
                    .addComponent(cbCity, 0, 155, Short.MAX_VALUE)
                    .addComponent(cbClients, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cbStatus, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbStatus)
                    .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(lbClientId))
                    .addComponent(cbClients, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtStreet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(street_lb)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtExteriorNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ext_num_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtInteriorNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(int_num_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNeighborhood, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(neigh_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPostalCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(postal_code_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(city_lb))
                .addGap(18, 18, 18))
        );

        add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 30, -1, 280));

        lbProjectId2.setText("Project id:");
        add(lbProjectId2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 170, -1, -1));

        txtProjectId2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProjectId2ActionPerformed(evt);
            }
        });
        add(txtProjectId2, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 170, 60, -1));

        btnClean.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnClean.setText("Clean");
        btnClean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCleanActionPerformed(evt);
            }
        });
        add(btnClean, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 20, -1, -1));

        btnAddressTable.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnAddressTable.setText("Addresses");
        btnAddressTable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddressTableActionPerformed(evt);
            }
        });
        add(btnAddressTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 270, -1, -1));

        tables.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout tablesLayout = new javax.swing.GroupLayout(tables);
        tables.setLayout(tablesLayout);
        tablesLayout.setHorizontalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 680, Short.MAX_VALUE)
        );
        tablesLayout.setVerticalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );

        add(tables, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 680, 370));

        btnProjectTable.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnProjectTable.setText("Projects");
        btnProjectTable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProjectTableActionPerformed(evt);
            }
        });
        add(btnProjectTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 270, -1, -1));

        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 100, 120, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void limpiarCampos() {
        txtProjectId.setText("");
        txtNameProject.setText("");
        txtADescProject.setText("");
        jdcStartDate.setDate(null);
        jdcEndDate.setDate(null);
        cbClients.setSelectedIndex(0);
        cbStatus.setSelectedIndex(0);

        txtProjectId2.setText("");

        txtStreet.setText("");
        txtExteriorNum.setText("");
        txtInteriorNum.setText("");
        txtNeighborhood.setText("");
        txtPostalCode.setText("");
        cbCity.setSelectedIndex(0);
    }

    private void ShowPanel(JPanel p) {
        p.setSize(680, 370);
        p.setLocation(0, 0);

        tables.removeAll();
        tables.add(p, BorderLayout.CENTER);
        tables.revalidate();
        tables.repaint();
    }

    private Map<String, Integer> cityMap = new HashMap<>();

    private void cargarCiudades() {
        try {
            CityDAO cityDAO = new CityDAO(DatabaseConnection.getConnection());
            List<City> cities = cityDAO.getAllCities();

            cbCity.removeAllItems();
            cityMap.clear();

            cbCity.addItem("Select city");

            for (City city : cities) {
                cbCity.addItem(city.getCity_name()); 
                cityMap.put(city.getCity_name(), city.getCity_id()); 
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private int getSelectedCityId() {
        String selectedCityName = (String) cbCity.getSelectedItem(); 

        if (selectedCityName == null || selectedCityName.equals("Select city")) {
            return -1; 
        }

        return cityMap.getOrDefault(selectedCityName, -1); 
    }

    private java.sql.Date getSqlDateFromChooser(JDateChooser dateChooser) {
        if (dateChooser.getDate() != null) {
            Date mBirthDate = dateChooser.getDate();
            long date = mBirthDate.getTime();
            return new java.sql.Date(date);
        } else {
            return null; 
        }
    }

    private Map<Integer, String> clientMap = new HashMap<>(); 

    private void cargarClientesEnComboBox() {
        try {
            String query = "SELECT client_id, CONCAT(first_name, ' ', last_name) AS full_name FROM client";
            ResultSet resultSet = DatabaseConnection.getConnection().createStatement().executeQuery(query);

            cbClients.removeAllItems(); 

            cbClients.addItem("Select client"); 

            while (resultSet.next()) {
                int id = resultSet.getInt("client_id");
                String fullName = resultSet.getString("full_name");
                String displayValue = id + " - " + fullName;

                cbClients.addItem(displayValue); 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private int getSelectedClientId() {
        String selectedClient = (String) cbClients.getSelectedItem(); 

        if (selectedClient == null || selectedClient.equals("Select client")) {
            return -1; 
        }

        try {
            String[] parts = selectedClient.split(" - ");
            return Integer.parseInt(parts[0]); 
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return -1; 
        }
    }

    private Map<String, Integer> statusMap = new HashMap<>();

    private void cargarStatus() {
        try {
            String query = "SELECT status_id, status_name FROM project_status";
            ResultSet resultSet = DatabaseConnection.getConnection().createStatement().executeQuery(query);

            cbStatus.removeAllItems();
            statusMap.clear();

            cbStatus.addItem("Select status");

            while (resultSet.next()) {
                int id = resultSet.getInt("status_id");
                String name = resultSet.getString("status_name");
                statusMap.put(name, id);
                cbStatus.addItem(name);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private int getSelectedStatusId() {
        String selectedStatusName = (String) cbStatus.getSelectedItem();

        if (selectedStatusName == null || selectedStatusName.equals("Select status")) {
            return -1; 
        }

        return statusMap.getOrDefault(selectedStatusName, -1); 
    }


    private void btnAddProjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddProjectActionPerformed
        try {
            String projectName = txtNameProject.getText().trim();
            String description = txtADescProject.getText().trim();
            Integer clientId = getSelectedClientId(); 
            System.out.println("Client ID seleccionado: " + clientId);

            if (clientId == -1) {
                JOptionPane.showMessageDialog(this, "Por favor, selecciona un cliente válido.",
                        "Error", JOptionPane.WARNING_MESSAGE);
                return; 
            }

            java.sql.Date startDateSQL = getSqlDateFromChooser(jdcStartDate);
            java.sql.Date endDateSQL = getSqlDateFromChooser(jdcEndDate);
            int statusId = getSelectedStatusId();

            if (projectName.isEmpty() || startDateSQL == null || endDateSQL == null || statusId == -1) {
                JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.",
                        "Campos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String streetName = txtStreet.getText().trim().isEmpty() ? null : txtStreet.getText().trim();
            String exteriorNum = txtExteriorNum.getText().trim().isEmpty() ? null : txtExteriorNum.getText().trim();
            String interiorNum = txtInteriorNum.getText().trim().isEmpty() ? null : txtInteriorNum.getText().trim();
            String neighborhoodName = txtNeighborhood.getText().trim().isEmpty() ? null : txtNeighborhood.getText().trim();
            String postalCode = txtPostalCode.getText().trim().isEmpty() ? null : txtPostalCode.getText().trim();
            Integer cityId = getSelectedCityId() == -1 ? null : getSelectedCityId();

            ProjectDAO projectDAO = new ProjectDAO(DatabaseConnection.getConnection());
            projectDAO.insertProject(
                    projectName, description, clientId, startDateSQL, endDateSQL, statusId,
                    streetName, exteriorNum, interiorNum, neighborhoodName, postalCode, cityId);

            JOptionPane.showMessageDialog(this, "Proyecto insertado exitosamente.");

            Project_Table p = new Project_Table();
            ShowPanel(p);

            limpiarCampos();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al insertar el proyecto: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_btnAddProjectActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        try {
            String projectIdText = txtProjectId2.getText().trim();
            if (projectIdText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El campo Project ID no puede estar vacío.");
                return;
            }

            int projectId;
            try {
                projectId = Integer.parseInt(projectIdText);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Por favor, ingresa un número válido en el campo Project ID.");
                return;
            }

            ProjectDAO projectDAO = new ProjectDAO(DatabaseConnection.getConnection());
            Object[] projectData = projectDAO.getProjectData(projectId);

            if (projectData == null || projectData[0] == null) {
                JOptionPane.showMessageDialog(this, "No se encontró un proyecto con el ID especificado.");
                return;
            }

            // Extraer datos del proyecto y de la dirección
            Project project = (Project) projectData[0];
            Address address = (Address) projectData[1];

            // Llenar los campos del formulario
            txtProjectId.setText(String.valueOf(project.getProjectId()));
            txtNameProject.setText(project.getProjectName());
            txtADescProject.setText(project.getDescription());
            jdcStartDate.setDate(project.getStartDate());
            jdcEndDate.setDate(project.getEndDate());
            cbStatus.setSelectedItem(project.getStatusName()); // Seleccionar el nombre del status en el ComboBox

            String clientDisplayValue = project.getClientId() + " - " + project.getClientName();
            cbClients.setSelectedItem(clientDisplayValue);

            if (address != null) {
                txtStreet.setText(address.getStreet());
                txtExteriorNum.setText(address.getExteriorNumber());
                txtInteriorNum.setText(address.getInteriorNumber() != null ? address.getInteriorNumber() : "");
                txtNeighborhood.setText(address.getNeighborhood());
                txtPostalCode.setText(address.getPostalCode());

                // Mapeo del city_id al nombre de la ciudad
                String cityName = null;
                for (Map.Entry<String, Integer> entry : cityMap.entrySet()) {
                    if (entry.getValue() == address.getCityId()) {
                        cityName = entry.getKey();
                        break;
                    }
                }
                if (cityName != null) {
                    cbCity.setSelectedItem(cityName);
                } else {
                    cbCity.setSelectedIndex(0); // Seleccionar la primera opción si no encuentra el ID
                }
            } else {
                // Si no hay dirección asociada, limpiar campos de dirección
                txtStreet.setText("");
                txtExteriorNum.setText("");
                txtInteriorNum.setText("");
                txtNeighborhood.setText("");
                txtPostalCode.setText("");
                cbCity.setSelectedIndex(0);
            }

            JOptionPane.showMessageDialog(this, "Proyecto cargado correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al buscar el proyecto: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        try {
            // Obtener el ID del proyecto
            int projectId = Integer.parseInt(txtProjectId.getText().trim());

            // Confirmación antes de eliminar
            int confirm = JOptionPane.showConfirmDialog(this,
                    "¿Está seguro de que desea eliminar este proyecto?",
                    "Confirmar eliminación",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                // Llamar al DAO para eliminar el proyecto
                ProjectDAO projectDAO = new ProjectDAO(DatabaseConnection.getConnection());
                projectDAO.deleteProject(projectId);

                JOptionPane.showMessageDialog(this, "Proyecto eliminado exitosamente.");

                // Actualizar la tabla
                Project_Table p = new Project_Table();
                ShowPanel(p);

                // Limpiar los campos
                limpiarCampos();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID del proyecto no válido.",
                    "Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al eliminar el proyecto: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_btnDeleteActionPerformed


    private void txtProjectId2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProjectId2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtProjectId2ActionPerformed

    private void txtNameProjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameProjectActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNameProjectActionPerformed

    private void txtProjectIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProjectIdActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_txtProjectIdActionPerformed

    private void btnCleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCleanActionPerformed
        // TODO add your handling code here:
        limpiarCampos();
    }//GEN-LAST:event_btnCleanActionPerformed

    private void btnAddressTableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddressTableActionPerformed
        // TODO add your handling code here:
        Address_Table p = new Address_Table();
        ShowPanel(p);
    }//GEN-LAST:event_btnAddressTableActionPerformed

    private void cbCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCityActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_cbCityActionPerformed

    private void btnProjectTableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProjectTableActionPerformed
        // TODO add your handling code here:
        Project_Table p = new Project_Table();
        ShowPanel(p);

    }//GEN-LAST:event_btnProjectTableActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        try {
            // Capturar datos del formulario
            int projectId = Integer.parseInt(txtProjectId.getText().trim());
            String projectName = txtNameProject.getText().trim();
            String description = txtADescProject.getText().trim();
            int clientId = getSelectedClientId();
            java.sql.Date startDateSQL = getSqlDateFromChooser(jdcStartDate);
            java.sql.Date endDateSQL = getSqlDateFromChooser(jdcEndDate);
            int statusId = getSelectedStatusId();
            String streetName = txtStreet.getText().trim();
            String exteriorNum = txtExteriorNum.getText().trim();
            String interiorNum = txtInteriorNum.getText().trim();
            String neighborhoodName = txtNeighborhood.getText().trim();
            String postalCode = txtPostalCode.getText().trim();
            int cityId = getSelectedCityId();

            // Validar campos obligatorios
            if (projectName.isEmpty() || startDateSQL == null || endDateSQL == null
                    || statusId == -1 || clientId == -1 || streetName.isEmpty()
                    || exteriorNum.isEmpty() || neighborhoodName.isEmpty() || postalCode.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.",
                        "Campos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Llamar al DAO para actualizar el proyecto
            ProjectDAO projectDAO = new ProjectDAO(DatabaseConnection.getConnection());
            projectDAO.updateProject(projectId, projectName, description, clientId, startDateSQL, endDateSQL,
                    statusId, streetName, exteriorNum, interiorNum, neighborhoodName, postalCode, cityId);

            JOptionPane.showMessageDialog(this, "Proyecto actualizado exitosamente.");

            // Actualizar la tabla de proyectos
            Project_Table p = new Project_Table();
            ShowPanel(p);

            // Limpiar los campos
            limpiarCampos();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al actualizar el proyecto: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID del proyecto no válido.",
                    "Error", JOptionPane.WARNING_MESSAGE);
        }

    }//GEN-LAST:event_btnUpdateActionPerformed

    private void cbClientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbClientsActionPerformed
        Integer clientId = getSelectedClientId();
        if (clientId != null) {
            System.out.println("Client ID seleccionado: " + clientId);

        }
    }//GEN-LAST:event_cbClientsActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddProject;
    private javax.swing.JButton btnAddressTable;
    private javax.swing.JButton btnClean;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnProjectTable;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cbCity;
    private javax.swing.JComboBox<String> cbClients;
    private javax.swing.JComboBox<String> cbStatus;
    private javax.swing.JLabel city_lb;
    private javax.swing.JLabel ext_num_lb;
    private javax.swing.JLabel int_num_lb;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private com.toedter.calendar.JDateChooser jdcEndDate;
    private com.toedter.calendar.JDateChooser jdcStartDate;
    private javax.swing.JLabel lbClientId;
    private javax.swing.JLabel lbDescription;
    private javax.swing.JLabel lbEndDate;
    private javax.swing.JLabel lbProject;
    private javax.swing.JLabel lbProjectId;
    private javax.swing.JLabel lbProjectId2;
    private javax.swing.JLabel lbProjectName;
    private javax.swing.JLabel lbStartDate;
    private javax.swing.JLabel lbStatus;
    private javax.swing.JLabel neigh_lb;
    private javax.swing.JLabel postal_code_lb;
    private javax.swing.JLabel street_lb;
    private javax.swing.JPanel tables;
    private javax.swing.JTextArea txtADescProject;
    private javax.swing.JTextField txtExteriorNum;
    private javax.swing.JTextField txtInteriorNum;
    private javax.swing.JTextField txtNameProject;
    private javax.swing.JTextField txtNeighborhood;
    private javax.swing.JTextField txtPostalCode;
    private javax.swing.JTextField txtProjectId;
    private javax.swing.JTextField txtProjectId2;
    private javax.swing.JTextField txtStreet;
    // End of variables declaration//GEN-END:variables
}
