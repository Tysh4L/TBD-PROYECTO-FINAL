package gui;

import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.awt.BorderLayout;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import logica.City;
import persistencia.CityDAO;
import persistencia.ClientDAO;
import persistencia.DatabaseConnection;
import java.util.Date;
import logica.Client;
import logica.Address;

public class guiClient extends javax.swing.JPanel {

    public guiClient() {
        initComponents();
        cargarCiudades();
        txtRFC.setEditable(false);
        txtClientId.setEditable(false);


        Client_Table p = new Client_Table();
        ShowPanel(p);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CLIENT_LB = new javax.swing.JLabel();
        add_clients_btn = new javax.swing.JButton();
        Search_btn = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        gender_lb = new javax.swing.JLabel();
        cbGender = new javax.swing.JComboBox<>();
        txtLastName = new javax.swing.JTextField();
        last_name_lb = new javax.swing.JLabel();
        company_name_lb = new javax.swing.JLabel();
        txtCompanyName = new javax.swing.JTextField();
        first_name_lb = new javax.swing.JLabel();
        txtFirstName = new javax.swing.JTextField();
        txtClientId = new javax.swing.JTextField();
        client_id_lb = new javax.swing.JLabel();
        birthDatelb = new javax.swing.JLabel();
        jdcBirthDate = new com.toedter.calendar.JDateChooser();
        txtRFC = new javax.swing.JTextField();
        RFClb = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        street_lb = new javax.swing.JLabel();
        txtInteriorNum = new javax.swing.JTextField();
        ext_num_lb = new javax.swing.JLabel();
        txtExteriorNum = new javax.swing.JTextField();
        txtStreet = new javax.swing.JTextField();
        int_num_lb = new javax.swing.JLabel();
        neigh_lb = new javax.swing.JLabel();
        txtNeighborhood = new javax.swing.JTextField();
        txtPostalCode = new javax.swing.JTextField();
        cbCity = new javax.swing.JComboBox<>();
        postal_code_lb = new javax.swing.JLabel();
        city_lb = new javax.swing.JLabel();
        phone_number_lb = new javax.swing.JLabel();
        txtPhone = new javax.swing.JTextField();
        email_lb = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        client_id_lb2 = new javax.swing.JLabel();
        client_id_txtfld = new javax.swing.JTextField();
        btnClean = new javax.swing.JButton();
        phone_table_btn = new javax.swing.JButton();
        address_table_btn1 = new javax.swing.JButton();
        tables = new javax.swing.JPanel();
        clients_table_btn1 = new javax.swing.JButton();
        update_client_btn1 = new javax.swing.JButton();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CLIENT_LB.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        CLIENT_LB.setText("Client");
        add(CLIENT_LB, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 113, -1));

        add_clients_btn.setText("Save");
        add_clients_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_clients_btnActionPerformed(evt);
            }
        });
        add(add_clients_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 70, 120, -1));

        Search_btn.setText("Search");
        Search_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Search_btnActionPerformed(evt);
            }
        });
        add(Search_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 200, 120, -1));

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 130, 120, -1));

        gender_lb.setText("Gender:");

        cbGender.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "F", "M" }));

        txtLastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLastNameActionPerformed(evt);
            }
        });

        last_name_lb.setText("Last name:");

        company_name_lb.setText("Company:");

        txtCompanyName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCompanyNameActionPerformed(evt);
            }
        });

        first_name_lb.setText("First name:");

        txtFirstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFirstNameActionPerformed(evt);
            }
        });

        txtClientId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtClientIdActionPerformed(evt);
            }
        });

        client_id_lb.setText("Client id:");

        birthDatelb.setText("Birth date:");

        jdcBirthDate.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N

        txtRFC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRFCActionPerformed(evt);
            }
        });

        RFClb.setText("RFC:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(gender_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(company_name_lb, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(last_name_lb, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE)))
                                .addGap(18, 18, 18))
                            .addComponent(first_name_lb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(client_id_lb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(birthDatelb, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(RFClb, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtRFC, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(txtLastName, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(txtCompanyName, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(cbGender, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtFirstName)
                    .addComponent(txtClientId)
                    .addComponent(jdcBirthDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(39, 39, 39))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(client_id_lb)
                    .addComponent(txtClientId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(first_name_lb)
                    .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(last_name_lb)
                    .addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCompanyName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(company_name_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RFClb)
                    .addComponent(txtRFC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbGender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gender_lb))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(birthDatelb)
                    .addComponent(jdcBirthDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 240, 270));

        street_lb.setText("Street:");

        ext_num_lb.setText("Exterior number:");

        int_num_lb.setText("Interior number:");

        neigh_lb.setText("Neighborhood:");

        cbCity.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        cbCity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbCityActionPerformed(evt);
            }
        });

        postal_code_lb.setText("Postal code:");

        city_lb.setText("City:");

        phone_number_lb.setText("Phone number:");

        txtPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPhoneActionPerformed(evt);
            }
        });

        email_lb.setText("Email:");

        txtEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(ext_num_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(int_num_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(neigh_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(street_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(postal_code_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(city_lb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(email_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(phone_number_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtEmail)
                    .addComponent(txtPhone)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtStreet)
                            .addComponent(txtExteriorNum)
                            .addComponent(txtInteriorNum)
                            .addComponent(txtNeighborhood)
                            .addComponent(txtPostalCode)
                            .addComponent(cbCity, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtStreet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(street_lb)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtExteriorNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ext_num_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtInteriorNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(int_num_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNeighborhood, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(neigh_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPostalCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(postal_code_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(city_lb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email_lb)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phone_number_lb)
                    .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );

        add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 60, -1, 260));

        client_id_lb2.setText("Client id:");
        add(client_id_lb2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 170, -1, -1));

        client_id_txtfld.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                client_id_txtfldActionPerformed(evt);
            }
        });
        add(client_id_txtfld, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 170, 60, -1));

        btnClean.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        btnClean.setText("Clean");
        btnClean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCleanActionPerformed(evt);
            }
        });
        add(btnClean, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 20, -1, -1));

        phone_table_btn.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        phone_table_btn.setText("Phone numbers");
        phone_table_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phone_table_btnActionPerformed(evt);
            }
        });
        add(phone_table_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 230, -1, -1));

        address_table_btn1.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        address_table_btn1.setText("Addresses");
        address_table_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                address_table_btn1ActionPerformed(evt);
            }
        });
        add(address_table_btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 270, -1, -1));

        tables.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout tablesLayout = new javax.swing.GroupLayout(tables);
        tables.setLayout(tablesLayout);
        tablesLayout.setHorizontalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        tablesLayout.setVerticalGroup(
            tablesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        add(tables, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 680, 370));

        clients_table_btn1.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        clients_table_btn1.setText("Clients");
        clients_table_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clients_table_btn1ActionPerformed(evt);
            }
        });
        add(clients_table_btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 270, -1, -1));

        update_client_btn1.setText("Update");
        update_client_btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_client_btn1ActionPerformed(evt);
            }
        });
        add(update_client_btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 100, 120, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void limpiarCampos() {
        txtClientId.setText("");
        txtFirstName.setText("");
        txtLastName.setText("");
        txtCompanyName.setText("");
        txtRFC.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        jdcBirthDate.setDate(null);
        txtStreet.setText("");
        txtExteriorNum.setText("");
        txtInteriorNum.setText("");
        txtNeighborhood.setText("");
        txtPostalCode.setText("");
        client_id_txtfld.setText("");
        cbCity.setSelectedIndex(0);
        cbGender.setSelectedIndex(0);
    }

    private void ShowPanel(JPanel p) {
        p.setSize(680, 370);
        p.setLocation(0, 0);

        tables.removeAll();
        tables.add(p, BorderLayout.CENTER);
        tables.revalidate();
        tables.repaint();
    }

    private Map<String, Integer> cityMap = new HashMap<>();

    private void cargarCiudades() {
        try {
            CityDAO cityDAO = new CityDAO(DatabaseConnection.getConnection());
            List<City> cities = cityDAO.getAllCities();

            cbCity.removeAllItems();
            cityMap.clear();

            cbCity.addItem("Select city");

            for (City city : cities) {
                cbCity.addItem(city.getCity_name()); 
                cityMap.put(city.getCity_name(), city.getCity_id()); 
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private int getSelectedCityId() {
        String selectedCityName = (String) cbCity.getSelectedItem(); 

        if (cityMap.containsKey(selectedCityName)) {
            return cityMap.get(selectedCityName); 
        } else {
            throw new RuntimeException("City ID not found for: " + selectedCityName);
        }
    }

    private java.sql.Date getSqlDateFromChooser(JDateChooser dateChooser) {
        if (dateChooser.getDate() != null) {
            Date mBirthDate = dateChooser.getDate();
            long date = mBirthDate.getTime();
            return new java.sql.Date(date);
        } else {
            return null; 
        }
    }


    private void add_clients_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_clients_btnActionPerformed
        // TODO add your handling code here:
        try {
            // Capturar datos de los campos del formulario
            String firstName = txtFirstName.getText().trim();
            String lastName = txtLastName.getText().trim();
            String companyName = txtCompanyName.getText().trim();
            String email = txtEmail.getText().trim();
            String gender = (String) cbGender.getSelectedItem();
            java.sql.Date birthDateSQL = getSqlDateFromChooser(jdcBirthDate);
            String phone = txtPhone.getText().trim();
            String streetName = txtStreet.getText().trim();
            String exteriorNum = txtExteriorNum.getText().trim();
            String neighborhoodName = txtNeighborhood.getText().trim();
            String postalCode = txtPostalCode.getText().trim();

            // Validar campos vacíos
            if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty()
                    || phone.isEmpty() || streetName.isEmpty() || exteriorNum.isEmpty()
                    || neighborhoodName.isEmpty() || postalCode.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.",
                        "Campos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Verificar que la fecha de nacimiento no sea nula
            if (birthDateSQL == null) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar una fecha de nacimiento.",
                        "Fecha de nacimiento requerida", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Obtener el ID de la ciudad seleccionada
            int cityId = getSelectedCityId();

            // Llamar al método del DAO
            ClientDAO clientDAO = new ClientDAO(DatabaseConnection.getConnection());
            clientDAO.insertClient(
                    firstName, lastName, companyName, email, gender, birthDateSQL,
                    phone, streetName, exteriorNum, null, neighborhoodName, postalCode, cityId);

            JOptionPane.showMessageDialog(this, "Cliente guardado exitosamente.");

            // Actualizar la tabla
            Client_Table p = new Client_Table();
            ShowPanel(p);

            // Limpiar los campos después de guardar
            limpiarCampos();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al guardar el cliente: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_add_clients_btnActionPerformed

    private void Search_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Search_btnActionPerformed
        // TODO add your handling code here:
        try {
            // Validar el ID del cliente
            String clientIdText = client_id_txtfld.getText().trim();
            if (clientIdText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El campo Client ID no puede estar vacío.");
                return;
            }

            int clientId;
            try {
                clientId = Integer.parseInt(clientIdText);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Por favor, ingresa un número válido en el campo Client ID.");
                return;
            }

            // Buscar los datos del cliente
            ClientDAO clientDAO = new ClientDAO(DatabaseConnection.getConnection());
            Object[] clientData = clientDAO.getClientData(clientId);

            if (clientData == null || clientData[0] == null) {
                JOptionPane.showMessageDialog(this, "No se encontró un cliente con el ID especificado.");
                return;
            }

            Client client = (Client) clientData[0];
            Address address = (Address) clientData[1];
            String phoneNumbers = (String) clientData[2];

            // Llenar los campos del formulario
            txtClientId.setText(String.valueOf(client.getClientId()));
            txtFirstName.setText(client.getFirstName());
            txtLastName.setText(client.getLastName());
            txtCompanyName.setText(client.getCompanyName());
            txtRFC.setText(client.getRfc());
            txtEmail.setText(client.getEmail());
            txtPhone.setText(phoneNumbers);
            cbGender.setSelectedItem(client.getGender());
            txtStreet.setText(address.getStreet());
            txtExteriorNum.setText(address.getExteriorNumber());
            txtInteriorNum.setText(address.getInteriorNumber() != null ? address.getInteriorNumber() : "");
            txtNeighborhood.setText(address.getNeighborhood());
            txtPostalCode.setText(address.getPostalCode());

            // Llenar el campo de fecha de nacimiento
            if (client.getBirthDate() != null) {
                jdcBirthDate.setDate(client.getBirthDate());
            } else {
                jdcBirthDate.setDate(null);
            }

            // Mapeo del city_id al nombre de la ciudad**
            String cityName = null;
            for (Map.Entry<String, Integer> entry : cityMap.entrySet()) {
                if (entry.getValue() == address.getCityId()) {
                    cityName = entry.getKey();
                    break;
                }
            }
            if (cityName != null) {
                cbCity.setSelectedItem(cityName); 
            } else {
                cbCity.setSelectedIndex(0); 
            }

            JOptionPane.showMessageDialog(this, "Cliente cargado correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al buscar el cliente: " + e.getMessage());
        }


    }//GEN-LAST:event_Search_btnActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        try {
            // Obtener el ID del cliente
            int clientId = Integer.parseInt(txtClientId.getText().trim());

            int confirm = JOptionPane.showConfirmDialog(this,
                    "¿Está seguro de que desea eliminar este cliente?",
                    "Confirmar eliminación",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                // Llamar al DAO para eliminar el cliente
                ClientDAO clientDAO = new ClientDAO(DatabaseConnection.getConnection());
                clientDAO.deleteClient(clientId);

                JOptionPane.showMessageDialog(this, "Cliente eliminado exitosamente.");

                // Actualizar la tabla
                Client_Table p = new Client_Table();
                ShowPanel(p);
                limpiarCampos();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID del cliente no válido.",
                    "Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al eliminar el cliente: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_btnDeleteActionPerformed

    private String[] getOldPhoneNumbers(int clientId) throws SQLException {
        ClientDAO clientDAO = new ClientDAO(DatabaseConnection.getConnection());
        return clientDAO.getClientPhoneNumbers(clientId); 
    }


    private void txtLastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLastNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLastNameActionPerformed

    private void txtCompanyNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCompanyNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCompanyNameActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void txtPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPhoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhoneActionPerformed

    private void client_id_txtfldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_client_id_txtfldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_client_id_txtfldActionPerformed

    private void txtFirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFirstNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFirstNameActionPerformed

    private void txtClientIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtClientIdActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_txtClientIdActionPerformed

    private void btnCleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCleanActionPerformed
        // TODO add your handling code here:
        limpiarCampos();
    }//GEN-LAST:event_btnCleanActionPerformed

    private void phone_table_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phone_table_btnActionPerformed
        // TODO add your handling code here:
        Client_Phone_Table p = new Client_Phone_Table();
        ShowPanel(p);
    }//GEN-LAST:event_phone_table_btnActionPerformed

    private void address_table_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_address_table_btn1ActionPerformed
        // TODO add your handling code here:
        Address_Table p = new Address_Table();
        ShowPanel(p);
    }//GEN-LAST:event_address_table_btn1ActionPerformed

    private void cbCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCityActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_cbCityActionPerformed

    private void txtRFCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRFCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRFCActionPerformed

    private void clients_table_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clients_table_btn1ActionPerformed
        // TODO add your handling code here:
        Client_Table p = new Client_Table();
        ShowPanel(p);

    }//GEN-LAST:event_clients_table_btn1ActionPerformed

    private void update_client_btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_client_btn1ActionPerformed
        try {
            // Capturar datos del formulario
            int clientId = Integer.parseInt(txtClientId.getText().trim());
            String firstName = txtFirstName.getText().trim();
            String lastName = txtLastName.getText().trim();
            String companyName = txtCompanyName.getText().trim();
            String email = txtEmail.getText().trim();
            String gender = (String) cbGender.getSelectedItem();
            java.sql.Date birthDateSQL = getSqlDateFromChooser(jdcBirthDate);
            String phone = txtPhone.getText().trim();
            String streetName = txtStreet.getText().trim();
            String exteriorNum = txtExteriorNum.getText().trim();
            String interiorNum = txtInteriorNum.getText().trim();
            String neighborhoodName = txtNeighborhood.getText().trim();
            String postalCode = txtPostalCode.getText().trim();
            int cityId = getSelectedCityId();

            // Validar campos obligatorios
            if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || phone.isEmpty() || streetName.isEmpty()
                    || exteriorNum.isEmpty() || neighborhoodName.isEmpty() || postalCode.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.",
                        "Campos incompletos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Llamar al DAO para actualizar cliente y dirección
            ClientDAO clientDAO = new ClientDAO(DatabaseConnection.getConnection());
            clientDAO.updateClientAndAddress(clientId, firstName, lastName, companyName, email, gender, birthDateSQL, phone,
                    streetName, exteriorNum, interiorNum, neighborhoodName, postalCode, cityId);

            // Procesar y comparar números telefónicos
            String[] newPhoneNumbers = phone.split(","); // Nuevos números
            String[] oldPhoneNumbers = getOldPhoneNumbers(clientId); // Obtener los números antiguos

            // Eliminar números telefónicos que ya no están en el nuevo campo
            for (String oldPhone : oldPhoneNumbers) {
                boolean existsInNew = false;
                for (String newPhone : newPhoneNumbers) {
                    if (oldPhone.trim().equals(newPhone.trim())) {
                        existsInNew = true;
                        break;
                    }
                }
                if (!existsInNew) {
                    clientDAO.deletePhone(clientId, oldPhone.trim());
                }
            }

            // Insertar o actualizar números nuevos
            for (String newPhone : newPhoneNumbers) {
                boolean existsInOld = false;
                for (String oldPhone : oldPhoneNumbers) {
                    if (oldPhone.trim().equals(newPhone.trim())) {
                        existsInOld = true;
                        break;
                    }
                }
                if (!existsInOld) {
                    clientDAO.updatePhone(clientId, "", newPhone.trim());
                }
            }

            JOptionPane.showMessageDialog(this, "Cliente actualizado exitosamente.");

            // Actualizar la tabla
            Client_Table p = new Client_Table();
            ShowPanel(p);

            // Limpiar los campos
            limpiarCampos();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al actualizar el cliente: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID del cliente no válido.",
                    "Error", JOptionPane.WARNING_MESSAGE);
        }


    }//GEN-LAST:event_update_client_btn1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel CLIENT_LB;
    private javax.swing.JLabel RFClb;
    private javax.swing.JButton Search_btn;
    private javax.swing.JButton add_clients_btn;
    private javax.swing.JButton address_table_btn1;
    private javax.swing.JLabel birthDatelb;
    private javax.swing.JButton btnClean;
    private javax.swing.JButton btnDelete;
    private javax.swing.JComboBox<String> cbCity;
    private javax.swing.JComboBox<String> cbGender;
    private javax.swing.JLabel city_lb;
    private javax.swing.JLabel client_id_lb;
    private javax.swing.JLabel client_id_lb2;
    private javax.swing.JTextField client_id_txtfld;
    private javax.swing.JButton clients_table_btn1;
    private javax.swing.JLabel company_name_lb;
    private javax.swing.JLabel email_lb;
    private javax.swing.JLabel ext_num_lb;
    private javax.swing.JLabel first_name_lb;
    private javax.swing.JLabel gender_lb;
    private javax.swing.JLabel int_num_lb;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private com.toedter.calendar.JDateChooser jdcBirthDate;
    private javax.swing.JLabel last_name_lb;
    private javax.swing.JLabel neigh_lb;
    private javax.swing.JLabel phone_number_lb;
    private javax.swing.JButton phone_table_btn;
    private javax.swing.JLabel postal_code_lb;
    private javax.swing.JLabel street_lb;
    private javax.swing.JPanel tables;
    private javax.swing.JTextField txtClientId;
    private javax.swing.JTextField txtCompanyName;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtExteriorNum;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtInteriorNum;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextField txtNeighborhood;
    private javax.swing.JTextField txtPhone;
    private javax.swing.JTextField txtPostalCode;
    private javax.swing.JTextField txtRFC;
    private javax.swing.JTextField txtStreet;
    private javax.swing.JButton update_client_btn1;
    // End of variables declaration//GEN-END:variables
}
