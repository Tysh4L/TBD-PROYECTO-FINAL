package persistencia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import logica.Stage;

public class StageDAO {
    private Connection connection;

    public StageDAO(Connection connection) {
        this.connection = connection;
    }

    // Metodo para obtener las etapas con sus ids y nombres
    public List<Stage> getAllStages() throws SQLException {
        List<Stage> stages = new ArrayList<>();
        String query = "SELECT stage_id, stage_name FROM stage"; 

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Stage stage = new Stage();
                stage.setStage_id(rs.getInt("stage_id")); 
                stage.setStage_name(rs.getString("stage_name")); 
                stages.add(stage); 
            }
        }
        return stages;
    }
}
