package persistencia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import logica.Address;
import logica.Project;

public class ProjectDAO {

    private Connection connection;

    public ProjectDAO(Connection connection) {
        this.connection = connection;
    }

    // Metodo para obtener los proyectos con sus id y nombres
    public List<Project> getAllProjects() throws SQLException {
        List<Project> projects = new ArrayList<>();
        String query = "SELECT project_id, project_name FROM project ORDER BY project_id"; 

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Project project = new Project();
                project.setProjectId(rs.getInt("project_id")); 
                project.setProjectName(rs.getString("project_name")); 
                projects.add(project); 
            }
        }
        return projects;
    }

    // Método para insertar un proyecto usando un procedimiento almacenado
    public void insertProject(String projectName, String description, int clientId, java.sql.Date startDate,
            java.sql.Date endDate, int statusId, String streetName, String exteriorNum,
            String interiorNum, String neighborhoodName, String postalCode, Integer cityId)
            throws SQLException {
        String procedure = "{CALL Insert_Project(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";
        try (CallableStatement stmt = connection.prepareCall(procedure)) {
            stmt.setString(1, projectName);
            stmt.setString(2, description);
            stmt.setInt(3, clientId);
            stmt.setDate(4, startDate);
            stmt.setDate(5, endDate);
            stmt.setInt(6, statusId);

            if (streetName != null) {
                stmt.setString(7, streetName);
            } else {
                stmt.setNull(7, Types.VARCHAR);
            }
            if (exteriorNum != null) {
                stmt.setString(8, exteriorNum);
            } else {
                stmt.setNull(8, Types.VARCHAR);
            }
            if (interiorNum != null) {
                stmt.setString(9, interiorNum);
            } else {
                stmt.setNull(9, Types.VARCHAR);
            }
            if (neighborhoodName != null) {
                stmt.setString(10, neighborhoodName);
            } else {
                stmt.setNull(10, Types.VARCHAR);
            }
            if (postalCode != null) {
                stmt.setString(11, postalCode);
            } else {
                stmt.setNull(11, Types.VARCHAR);
            }
            if (cityId != null) {
                stmt.setInt(12, cityId);
            } else {
                stmt.setNull(12, Types.INTEGER);
            }

            stmt.execute();
        }
    }

    // Método para actualizar un proyecto
    public void updateProject(int projectId, String projectName, String description, int clientId,
            java.sql.Date startDate, java.sql.Date endDate, int statusId, String street,
            String exteriorNum, String interiorNum, String neighborhood, String postalCode, int cityId)
            throws SQLException {

        // Actualizar el proyecto
        String updateProjectQuery = "UPDATE project SET project_name = ?, description = ?, client_id = ?, "
                + "start_date = ?, end_date = ?, status_id = ? WHERE project_id = ?";
        try (PreparedStatement projectStmt = connection.prepareStatement(updateProjectQuery)) {
            projectStmt.setString(1, projectName);
            projectStmt.setString(2, description);
            projectStmt.setInt(3, clientId); 
            projectStmt.setDate(4, startDate); 
            projectStmt.setDate(5, endDate); 
            projectStmt.setInt(6, statusId); 
            projectStmt.setInt(7, projectId); 
            projectStmt.executeUpdate();
        }

        // Actualizar la dirección
        String updateAddressQuery = "UPDATE address SET street = ?, exterior_number = ?, interior_number = ?, "
                + "neighborhood = ?, postal_code = ?, city_id = ? WHERE address_id = (SELECT address_id FROM project WHERE project_id = ?)";
        try (PreparedStatement addressStmt = connection.prepareStatement(updateAddressQuery)) {
            addressStmt.setString(1, street); 
            addressStmt.setString(2, exteriorNum); 
            addressStmt.setString(3, interiorNum); 
            addressStmt.setString(4, neighborhood); 
            addressStmt.setString(5, postalCode); 
            addressStmt.setInt(6, cityId); 
            addressStmt.setInt(7, projectId); 
            addressStmt.executeUpdate();
        }
    }

    public Object[] getProjectData(int projectId) throws SQLException {
        String procedure = "{CALL GetProjectData(?)}";
        Project project = null;
        Address address = null;

        try (CallableStatement stmt = connection.prepareCall(procedure)) {
            stmt.setInt(1, projectId);
            boolean hasResults = stmt.execute();

            if (hasResults) {
                try (ResultSet rs = stmt.getResultSet()) {
                    if (rs.next()) {
                        project = new Project();
                        project.setProjectId(rs.getInt("project_id"));
                        project.setProjectName(rs.getString("project_name"));
                        project.setDescription(rs.getString("description"));
                        project.setClientId(rs.getInt("client_id"));
                        project.setClientName(rs.getString("client_name"));
                        project.setStartDate(rs.getDate("start_date"));
                        project.setEndDate(rs.getDate("end_date"));
                        project.setStatusName(rs.getString("status_name"));

                        address = new Address();
                        address.setStreet(rs.getString("street"));
                        address.setExteriorNumber(rs.getString("exterior_number"));
                        address.setInteriorNumber(rs.getString("interior_number"));
                        address.setNeighborhood(rs.getString("neighborhood"));
                        address.setPostalCode(rs.getString("postal_code"));
                        address.setCityId(rs.getInt("city_id"));
                    }
                }
            }
        }

        return new Object[]{project, address};
    }

    public void deleteProject(int projectId) throws SQLException {
        try {
            connection.setAutoCommit(false); 

            String deleteProjectQuery = "DELETE FROM project WHERE project_id = ?";
            try (PreparedStatement projectStmt = connection.prepareStatement(deleteProjectQuery)) {
                projectStmt.setInt(1, projectId);
                projectStmt.executeUpdate();
            }

            String deleteAddressQuery = "DELETE FROM address WHERE address_id = (SELECT address_id FROM project WHERE project_id = ?)";
            try (PreparedStatement addressStmt = connection.prepareStatement(deleteAddressQuery)) {
                addressStmt.setInt(1, projectId);
                addressStmt.executeUpdate();
            }

            connection.commit(); 
        } catch (SQLException ex) {
            connection.rollback(); 
            throw ex;
        } finally {
            connection.setAutoCommit(true); 
        }
    }

}
