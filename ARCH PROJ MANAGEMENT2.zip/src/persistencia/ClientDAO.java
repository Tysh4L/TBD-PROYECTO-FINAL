package persistencia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import logica.Address;
import logica.Client;

public class ClientDAO {

    private Connection connection;

    public ClientDAO(Connection connection) {
        this.connection = connection;
    }

    // Metodo para insertar un cliente con un procedimiento 
    public void insertClient(
            String firstName, String lastName, String companyName,
            String email, String gender, java.sql.Date birthDate, String phone,
            String streetName, String exteriorNum, String interiorNum,
            String neighborhoodName, String postalCode, int cityId) throws SQLException {

        String procedureCall = "{CALL Insert_Client(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        try (CallableStatement stmt = connection.prepareCall(procedureCall)) {
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, companyName);
            stmt.setString(4, email);
            stmt.setString(5, gender);
            stmt.setDate(6, birthDate);
            stmt.setString(7, phone);
            stmt.setString(8, streetName);
            stmt.setString(9, exteriorNum);
            stmt.setString(10, interiorNum);
            stmt.setString(11, neighborhoodName);
            stmt.setString(12, postalCode);
            stmt.setInt(13, cityId);

            stmt.execute();
        }
    }

    // Método para obtener los datos de un cliente por ID
    public Object[] getClientData(int clientId) throws SQLException {
        String procedure = "{CALL GetClientData(?)}";
        Client client = null;
        Address address = null;
        String phoneNumbers = "";

        try (CallableStatement stmt = connection.prepareCall(procedure)) {
            stmt.setInt(1, clientId);
            boolean hasResults = stmt.execute();

            // Primer conjunto de resultados: datos del cliente y la dirección
            if (hasResults) {
                try (ResultSet rs = stmt.getResultSet()) {
                    if (rs.next()) {
                        client = new Client();
                        client.setClientId(rs.getInt("client_id"));
                        client.setFirstName(rs.getString("first_name"));
                        client.setLastName(rs.getString("last_name"));
                        client.setCompanyName(rs.getString("company_name"));
                        client.setRfc(rs.getString("rfc"));
                        client.setEmail(rs.getString("email"));
                        client.setGender(rs.getString("gender"));
                        client.setBirthDate(rs.getDate("birth_date")); // Obtener birth_date

                        // Objeto Address con los datos de la dirección
                        address = new Address();
                        address.setStreet(rs.getString("street"));
                        address.setExteriorNumber(rs.getString("exterior_number"));
                        address.setInteriorNumber(rs.getString("interior_number"));
                        address.setNeighborhood(rs.getString("neighborhood"));
                        address.setPostalCode(rs.getString("postal_code"));
                        address.setCityId(rs.getInt("city_id"));
                    }
                }
            }

            // Cnjunto de resultados: números de teléfono
            if (stmt.getMoreResults()) {
                try (ResultSet rs = stmt.getResultSet()) {
                    List<String> phones = new ArrayList<>();
                    while (rs.next()) {
                        phones.add(rs.getString("phone_number"));
                    }
                    phoneNumbers = String.join(", ", phones);
                }
            }
        }

        return new Object[]{client, address, phoneNumbers};
    }

    public void updateClientAndAddress(int clientId, String firstName, String lastName, String companyName, String email,
            String gender, java.sql.Date birthDate, String phone,
            String streetName, String exteriorNum, String interiorNum,
            String neighborhoodName, String postalCode, int cityId) throws SQLException {
        // Actualizar cliente
        String updateClientQuery = "UPDATE client SET first_name = ?, last_name = ?, company_name = ?, email = ?, "
                + "gender = ?, birth_date = ? WHERE client_id = ?";
        try (PreparedStatement clientStmt = connection.prepareStatement(updateClientQuery)) {
            clientStmt.setString(1, firstName);
            clientStmt.setString(2, lastName);
            clientStmt.setString(3, companyName);
            clientStmt.setString(4, email);
            clientStmt.setString(5, gender);
            clientStmt.setDate(6, birthDate);
            clientStmt.setInt(7, clientId);
            clientStmt.executeUpdate();
        }

        // Actualizar dirección
        String updateAddressQuery = "UPDATE address SET street = ?, exterior_number = ?, interior_number = ?, "
                + "neighborhood = ?, postal_code = ?, city_id = ? WHERE address_id = (SELECT address_id FROM client WHERE client_id = ?)";
        try (PreparedStatement addressStmt = connection.prepareStatement(updateAddressQuery)) {
            addressStmt.setString(1, streetName);
            addressStmt.setString(2, exteriorNum);
            addressStmt.setString(3, interiorNum);
            addressStmt.setString(4, neighborhoodName);
            addressStmt.setString(5, postalCode);
            addressStmt.setInt(6, cityId);
            addressStmt.setInt(7, clientId);
            addressStmt.executeUpdate();
        }
    }

    public void updatePhone(int clientId, String oldPhone, String newPhone) throws SQLException {
        String callProcedureQuery = "{CALL UpdateClientPhone(?, ?, ?)}";
        try (CallableStatement callableStmt = connection.prepareCall(callProcedureQuery)) {
            callableStmt.setInt(1, clientId);
            callableStmt.setString(2, oldPhone); // Número antiguo
            callableStmt.setString(3, newPhone); // Número nuevo
            callableStmt.execute();
        }

    }

    public String[] getClientPhoneNumbers(int clientId) throws SQLException {
        String query = "SELECT phone_number FROM client_phone WHERE client_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, clientId);
            try (ResultSet rs = stmt.executeQuery()) {
                List<String> phoneNumbers = new ArrayList<>();
                while (rs.next()) {
                    phoneNumbers.add(rs.getString("phone_number"));
                }
                return phoneNumbers.toArray(new String[0]);
            }
        }
    }

    public void deletePhone(int clientId, String phoneNumber) throws SQLException {
        String deletePhoneQuery = "DELETE FROM client_phone WHERE client_id = ? AND phone_number = ?";
        try (PreparedStatement deleteStmt = connection.prepareStatement(deletePhoneQuery)) {
            deleteStmt.setInt(1, clientId);
            deleteStmt.setString(2, phoneNumber);
            deleteStmt.executeUpdate();
        }
    }

    public void deleteClient(int clientId) throws SQLException {
        try {
            connection.setAutoCommit(false); // Inicia una transacción

            // Eliminar cliente
            String deleteClientQuery = "DELETE FROM client WHERE client_id = ?";
            try (PreparedStatement clientStmt = connection.prepareStatement(deleteClientQuery)) {
                clientStmt.setInt(1, clientId);
                clientStmt.executeUpdate();
            }

            // Eliminar dirección del cliente
            String deleteAddressQuery = "DELETE FROM address WHERE address_id = (SELECT address_id FROM client WHERE client_id = ?)";
            try (PreparedStatement addressStmt = connection.prepareStatement(deleteAddressQuery)) {
                addressStmt.setInt(1, clientId);
                addressStmt.executeUpdate();
            }

            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    // Obtener todos los clientes
    public List<Client> getAllClients() throws SQLException {
        List<Client> clients = new ArrayList<>();
        String query = "SELECT * FROM client";

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Client client = new Client(
                        rs.getInt("client_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("company_name"),
                        rs.getString("rfc"),
                        rs.getString("email"),
                        rs.getString("gender"),
                        rs.getDate("birth_date"),
                        rs.getInt("address_id")
                // Obtener birth_date
                );
                clients.add(client);
            }
        }
        return clients;
    }

}
