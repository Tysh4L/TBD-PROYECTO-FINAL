package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    // Método para obtener una conexión con las credenciales de SessionManager
    public static Connection getConnection() throws SQLException {
        String username = SessionManager.getUsername();
        String password = SessionManager.getPassword();
        String url = "jdbc:mysql://localhost:3306/sbm?serverTimezone=America/Chicago";

        if (username == null || password == null) {
            throw new SQLException("Credenciales no configuradas en SessionManager");
        }

        System.out.println("Conectando a la base de datos con usuario: " + username);
        return DriverManager.getConnection(url, username, password);
    }

    public static Connection getConnection(String username, String password) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/sbm?serverTimezone=America/Chicago";
        return DriverManager.getConnection(url, username, password);
    }
}
