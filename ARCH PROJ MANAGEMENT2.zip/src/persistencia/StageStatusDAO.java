package persistencia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import logica.StageStatus;

public class StageStatusDAO {

    private Connection connection;

    public StageStatusDAO(Connection connection) {
        this.connection = connection;
    }
    
    public List<StageStatus> getAllStageStatus() throws SQLException {
        List<StageStatus> stageStatuses = new ArrayList<>();
        String query = "SELECT status_id, status_name FROM stage_status"; 

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                StageStatus stageStatus = new StageStatus();
                stageStatus.setStatus_id(rs.getInt("status_id")); 
                stageStatus.setStatus_name(rs.getString("status_name"));
                stageStatuses.add(stageStatus); 
            }
        }
        return stageStatuses;
    }
}

