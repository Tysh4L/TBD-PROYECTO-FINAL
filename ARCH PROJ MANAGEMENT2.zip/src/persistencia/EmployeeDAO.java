package persistencia;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import logica.Address;
import logica.Employee;

public class EmployeeDAO {

    private Connection connection;

    public EmployeeDAO(Connection connection) {
        this.connection = connection;
    }

    public void registerNewEmployee(
            String firstName, String lastName, Date birthDate, String gender,
            int departmentId, int buId, int jobPositionId, int specializationId,
            Date hireDate, String phoneNumbers, BigDecimal monthlySalary,
            String streetName, String exteriorNum, String interiorNum,
            String neighborhoodName, String postalCode, int cityId
    ) throws SQLException {

        String procedureCall = "{CALL Register_New_Employee(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        try (CallableStatement stmt = connection.prepareCall(procedureCall)) {
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setDate(3, new java.sql.Date(birthDate.getTime()));
            stmt.setString(4, gender);
            stmt.setInt(5, departmentId);
            stmt.setInt(6, buId);
            stmt.setInt(7, jobPositionId);
            stmt.setInt(8, specializationId);
            stmt.setDate(9, new java.sql.Date(hireDate.getTime()));
            stmt.setString(10, phoneNumbers);
            stmt.setBigDecimal(11, monthlySalary);
            stmt.setString(12, streetName);
            stmt.setString(13, exteriorNum);
            stmt.setString(14, interiorNum);
            stmt.setString(15, neighborhoodName);
            stmt.setString(16, postalCode);
            stmt.setInt(17, cityId);

            stmt.execute();
            System.out.println("Empleado registrado exitosamente.");
        }
    }

    public Object[] getEmployeeData(int employeeId) throws SQLException {
        String procedure = "{CALL GetEmployeeData(?)}";
        Employee employee = null;
        Address address = null;
        String phoneNumbers = "";
        String departmentName = "";
        String businessUnitName = "";
        String jobPositionName = "";
        String specializationName = "";

        try (CallableStatement stmt = connection.prepareCall(procedure)) {
            stmt.setInt(1, employeeId);
            boolean hasResults = stmt.execute();

            // Primer conjunto de resultados: datos del empleado, dirección y detalles del trabajo
            if (hasResults) {
                try (ResultSet rs = stmt.getResultSet()) {
                    if (rs.next()) {
                        // Datos del empleado
                        employee = new Employee();
                        employee.setEmployeeId(rs.getInt("employee_id"));
                        employee.setFirstName(rs.getString("first_name"));
                        employee.setLastName(rs.getString("last_name"));
                        employee.setBirthDate(rs.getDate("birth_date"));
                        employee.setRfc(rs.getString("rfc"));
                        employee.setGender(rs.getString("gender"));
                        employee.setEmail(rs.getString("email"));
                        employee.setMonthlySalary(rs.getBigDecimal("monthly_salary"));
                        employee.setHireDate(rs.getDate("hire_date"));

                        // Dirección
                        address = new Address();
                        address.setStreet(rs.getString("street"));
                        address.setExteriorNumber(rs.getString("exterior_number"));
                        address.setInteriorNumber(rs.getString("interior_number"));
                        address.setNeighborhood(rs.getString("neighborhood"));
                        address.setPostalCode(rs.getString("postal_code"));
                        address.setCityId(rs.getInt("city_id"));

                        // Información del trabajo
                        departmentName = rs.getString("department_name");
                        businessUnitName = rs.getString("business_unit_name");
                        jobPositionName = rs.getString("job_position_name");
                        specializationName = rs.getString("specialization_name");
                    }
                }
            }

            if (stmt.getMoreResults()) {
                try (ResultSet rs = stmt.getResultSet()) {
                    List<String> phones = new ArrayList<>();
                    while (rs.next()) {
                        phones.add(rs.getString("phone_number"));
                    }
                    phoneNumbers = String.join(", ", phones);
                }
            }
        }

        return new Object[]{employee, address, phoneNumbers, departmentName, businessUnitName, jobPositionName, specializationName};
    }

    public void updateEmployeeAndAddress(
            int employeeId, String firstName, String lastName, Date birthDate, String gender,
            int departmentId, int buId, int jobPositionId, int specializationId,
            Date hireDate, BigDecimal monthlySalary, String streetName, String exteriorNum,
            String interiorNum, String neighborhoodName, String postalCode, int cityId
    ) throws SQLException {

        String procedureCall = "{CALL Update_Employee(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        try (CallableStatement stmt = connection.prepareCall(procedureCall)) {
            stmt.setInt(1, employeeId);
            stmt.setString(2, firstName);
            stmt.setString(3, lastName);
            stmt.setDate(4, new java.sql.Date(birthDate.getTime()));
            stmt.setString(5, gender);
            stmt.setInt(6, departmentId);
            stmt.setInt(7, buId);
            stmt.setInt(8, jobPositionId);
            stmt.setInt(9, specializationId);
            stmt.setDate(10, new java.sql.Date(hireDate.getTime()));
            stmt.setBigDecimal(11, monthlySalary);
            stmt.setString(12, streetName);
            stmt.setString(13, exteriorNum);
            stmt.setString(14, interiorNum);
            stmt.setString(15, neighborhoodName);
            stmt.setString(16, postalCode);
            stmt.setInt(17, cityId);

            stmt.execute();
            System.out.println("Empleado actualizado exitosamente.");
        }
    }

    public void deleteEmployee(int employeeId) throws SQLException {
        String procedureCall = "{CALL Delete_Employee(?)}";

        try (CallableStatement stmt = connection.prepareCall(procedureCall)) {
            stmt.setInt(1, employeeId);
            stmt.execute();
            System.out.println("Empleado eliminado exitosamente.");
        }
    }

    public void updatePhone(int employeeId, String oldPhone, String newPhone) throws SQLException {
        String callProcedureQuery = "{CALL UpdateEmployeePhone(?, ?, ?)}";
        try (CallableStatement callableStmt = connection.prepareCall(callProcedureQuery)) {
            callableStmt.setInt(1, employeeId);
            callableStmt.setString(2, oldPhone);
            callableStmt.setString(3, newPhone);
            callableStmt.execute();
        }
    }

    public String[] getEmployeePhoneNumbers(int employeeId) throws SQLException {
        String query = "SELECT phone_number FROM employee_phone WHERE employee_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            try (ResultSet rs = stmt.executeQuery()) {
                List<String> phoneNumbers = new ArrayList<>();
                while (rs.next()) {
                    phoneNumbers.add(rs.getString("phone_number"));
                }
                return phoneNumbers.toArray(new String[0]);
            }
        }
    }

    public void deletePhone(int employeeId, String phoneNumber) throws SQLException {
        String deletePhoneQuery = "DELETE FROM employee_phone WHERE employee_id = ? AND phone_number = ?";
        try (PreparedStatement deleteStmt = connection.prepareStatement(deletePhoneQuery)) {
            deleteStmt.setInt(1, employeeId);
            deleteStmt.setString(2, phoneNumber);
            deleteStmt.executeUpdate();
        }
    }

}
