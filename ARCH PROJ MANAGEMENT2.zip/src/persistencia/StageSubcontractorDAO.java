package persistencia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import logica.StageSubcontractor;

public class StageSubcontractorDAO {
    private Connection connection;

    public StageSubcontractorDAO(Connection connection) {
        this.connection = connection;
    }

    // Obtener los datos
    public List<StageSubcontractor> getStageSubcontractor() throws SQLException {
        String query = "{CALL GetStageSubcontractor()}";
        List<StageSubcontractor> subcontractor = new ArrayList<>();
        try (CallableStatement stmt = connection.prepareCall(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                subcontractor.add(new StageSubcontractor(
                    rs.getInt("project_id"),
                    rs.getString("project_name"),
                    rs.getString("stage_name"),
                    rs.getString("company_name"),
                    rs.getInt("hours_used"),
                    rs.getBigDecimal("subcontractor_cost")
                ));
            }
        }
        return subcontractor;
    }

    // Insertar un registro
    public void insertStageSubcontractor(StageSubcontractor subcontractor) throws SQLException {
        String query = "{CALL InsertStageSubcontractor(?, ?, ?, ?, ?)}";
        try (CallableStatement stmt = connection.prepareCall(query)) {
            stmt.setInt(1, subcontractor.getProjectId());
            stmt.setInt(2, subcontractor.getStageId());
            stmt.setInt(3, subcontractor.getSubcontractorId());
            stmt.setInt(4, subcontractor.getHoursUsed());
            stmt.setBigDecimal(5, subcontractor.getSubcontractorCost());
            stmt.executeUpdate();
        }
    }

    // Actualizar un registro
    public void updateStageSubcontractor(StageSubcontractor subcontractor) throws SQLException {
        String query = "{CALL UpdateStageSubcontractor(?, ?, ?, ?, ?)}";
        try (CallableStatement stmt = connection.prepareCall(query)) {
            stmt.setInt(1, subcontractor.getProjectId());
            stmt.setInt(2, subcontractor.getStageId());
            stmt.setInt(3, subcontractor.getSubcontractorId());
            stmt.setInt(4, subcontractor.getHoursUsed());
            stmt.setBigDecimal(5, subcontractor.getSubcontractorCost());
            stmt.executeUpdate();
        }
    }

    // Eliminar un registro
    public void deleteStageSubcontractor(int projectId, int stageId, int subcontractorId) throws SQLException {
        String query = "{CALL DeleteStageSubcontractor(?, ?, ?)}";
        try (CallableStatement stmt = connection.prepareCall(query)) {
            stmt.setInt(1, projectId);
            stmt.setInt(2, stageId);
            stmt.setInt(3, subcontractorId);
            stmt.executeUpdate();
        }
    }
}
