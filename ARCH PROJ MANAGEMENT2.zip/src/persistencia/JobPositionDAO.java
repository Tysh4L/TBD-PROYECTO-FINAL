package persistencia;

import logica.JobPosition;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JobPositionDAO {

    private Connection connection;

    public JobPositionDAO(Connection connection) {
        this.connection = connection;
    }

    public List<JobPosition> getAllJobPositions() throws SQLException {
        String query = "SELECT JP_id, JP_name FROM job_position";
        List<JobPosition> jobPositions = new ArrayList<>();

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                JobPosition jobPosition = new JobPosition(
                        rs.getInt("JP_id"),
                        rs.getString("JP_name")
                );
                jobPositions.add(jobPosition);
            }
        }
        return jobPositions;
    }
}
