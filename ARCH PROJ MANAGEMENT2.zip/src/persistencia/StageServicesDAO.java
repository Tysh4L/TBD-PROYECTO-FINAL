package persistencia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import logica.StageService;

public class StageServicesDAO {
    private Connection connection;

    public StageServicesDAO(Connection connection) {
        this.connection = connection;
    }

    // Obtener los datos
    public List<StageService> getStageServices() throws SQLException {
        String query = "{CALL GetStageServices()}";
        List<StageService> services = new ArrayList<>();
        try (CallableStatement stmt = connection.prepareCall(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                services.add(new StageService(
                    rs.getInt("project_id"),
                    rs.getString("project_name"),
                    rs.getString("stage_name"),
                    rs.getString("service_name"),
                    rs.getInt("hours_used"),
                    rs.getBigDecimal("service_cost")
                ));
            }
        }
        return services;
    }

    // Insertar un registro
    public void insertStageService(StageService service) throws SQLException {
        String query = "{CALL InsertStageService(?, ?, ?, ?, ?)}";
        try (CallableStatement stmt = connection.prepareCall(query)) {
            stmt.setInt(1, service.getProjectId());
            stmt.setInt(2, service.getStageId());
            stmt.setInt(3, service.getServiceId());
            stmt.setInt(4, service.getHoursUsed());
            stmt.setBigDecimal(5, service.getServiceCost());
            stmt.executeUpdate();
        }
    }

    // Actualizar un registro
    public void updateStageService(StageService service) throws SQLException {
        String query = "{CALL UpdateStageService(?, ?, ?, ?, ?)}";
        try (CallableStatement stmt = connection.prepareCall(query)) {
            stmt.setInt(1, service.getProjectId());
            stmt.setInt(2, service.getStageId());
            stmt.setInt(3, service.getServiceId());
            stmt.setInt(4, service.getHoursUsed());
            stmt.setBigDecimal(5, service.getServiceCost());
            stmt.executeUpdate();
        }
    }

    // Eliminar un registro
    public void deleteStageService(int projectId, int stageId, int serviceId) throws SQLException {
        String query = "{CALL DeleteStageService(?, ?, ?)}";
        try (CallableStatement stmt = connection.prepareCall(query)) {
            stmt.setInt(1, projectId);
            stmt.setInt(2, stageId);
            stmt.setInt(3, serviceId);
            stmt.executeUpdate();
        }
    }
}
