package persistencia;

import java.sql.*;
import java.sql.Connection;

public class BudgetDAO {

    private Connection connection;

    public BudgetDAO(Connection connection) {
        this.connection = connection;
    }

    // Método para agregar un presupuesto
    public boolean addBudget(int projectId, int stageId) {
        String query = "INSERT INTO budget (project_id, stage_id) VALUES (?, ?)";

        try (PreparedStatement pst = connection.prepareStatement(query)) {
            // Establecer los valores en la consulta
            pst.setInt(1, projectId);
            pst.setInt(2, stageId);


            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) {
                System.out.println("Error: Duplicate entry for project_id and stage_id.");
                return false;  
            } else {
                e.printStackTrace(); 
                return false;
            }
        }
    }

    public boolean deleteBudget(int projectId, int stageId) {
        String query = "DELETE FROM budget WHERE project_id = ? AND stage_id = ?";

        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setInt(1, projectId);
            pst.setInt(2, stageId);

            int rowsAffected = pst.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
             e.printStackTrace();
            return false;  
        }
    }

}
