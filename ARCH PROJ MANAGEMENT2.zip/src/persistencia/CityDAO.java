package persistencia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import logica.City;

public class CityDAO {
    private Connection connection;
    
    public CityDAO(Connection connection) {
        this.connection = connection;
    }

 // Método para obtener las ciudades con sus IDs y nombres
    public List<City> getAllCities() throws SQLException {
        List<City> cities = new ArrayList<>();
        String query = "SELECT city_id, city_name FROM city"; 

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                City city = new City();
                city.setCity_id(rs.getInt("city_id")); 
                city.setCity_name(rs.getString("city_name")); 
                cities.add(city);
            }
        }
        return cities;
    }
}
