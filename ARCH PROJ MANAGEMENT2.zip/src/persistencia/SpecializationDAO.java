package persistencia;

import logica.Specialization;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SpecializationDAO {

    private Connection connection;

    public SpecializationDAO(Connection connection) {
        this.connection = connection;
    }

    public List<Specialization> getAllSpecializations() throws SQLException {
        String query = "SELECT SP_id, specialization_name FROM specialization";
        List<Specialization> specializations = new ArrayList<>();

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Specialization specialization = new Specialization(
                        rs.getInt("SP_id"),
                        rs.getString("specialization_name")
                );
                specializations.add(specialization);
            }
        }
        return specializations;
    }
}
