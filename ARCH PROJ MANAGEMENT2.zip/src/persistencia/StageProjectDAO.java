package persistencia;

import java.sql.*;
import logica.StageProject;

public class StageProjectDAO {

    private Connection conn;

    public StageProjectDAO(Connection conn) {
        this.conn = conn;
    }

    public void insertStageProject(StageProject stageProject) throws SQLException {
        String procedure = "{CALL AddStageProject(?, ?, ?, ?, ?)}";
        try (CallableStatement stmt = conn.prepareCall(procedure)) {
            stmt.setInt(1, stageProject.getProjectId());
            stmt.setInt(2, stageProject.getStageId());
            stmt.setDate(3, stageProject.getStartDate());
            stmt.setDate(4, stageProject.getDueDate());
            stmt.setInt(5, stageProject.getStatusId());

            stmt.executeUpdate();
        }
    }

    public void updateStageProject(StageProject stageProject) throws SQLException {
        String procedure = "{CALL UpdateStageProject(?, ?, ?, ?, ?)}";
        try (CallableStatement stmt = conn.prepareCall(procedure)) {
            stmt.setInt(1, stageProject.getProjectId());
            stmt.setInt(2, stageProject.getStageId());
            stmt.setDate(3, stageProject.getStartDate());
            stmt.setDate(4, stageProject.getDueDate());
            stmt.setInt(5, stageProject.getStatusId());

            stmt.executeUpdate();
        }
    }

    public boolean deleteStageProject(int projectId, int stageId) throws SQLException {
        String query = "{CALL DeleteStageProject(?, ?)}";
        try (CallableStatement stmt = conn.prepareCall(query)) {
            stmt.setInt(1, projectId);
            stmt.setInt(2, stageId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }
    }

}
