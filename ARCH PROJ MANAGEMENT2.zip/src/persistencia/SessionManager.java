package persistencia;

public class SessionManager {
    private static String username; 
    private static String password; 

    // Método para establecer las credenciales después del login
    public static void setCredentials(String user, String pass) {
        username = user;
        password = pass;
    }

    // Método para obtener el nombre de usuario actual
    public static String getUsername() {
        return username;
    }

    // Método para obtener la contraseña actual
    public static String getPassword() {
        return password;
    }

    // Método para limpiar las credenciales al cerrar sesión
    public static void clearCredentials() {
        username = null;
        password = null;
    }
}