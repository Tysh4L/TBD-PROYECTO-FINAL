package persistencia;

import java.sql.*;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class InvoiceDAO {

    private Connection connection;

    public InvoiceDAO(Connection connection) {
        this.connection = connection;
    }

    public List<String[]> getClientInvoices(int clientId) throws SQLException {
        String sql = "CALL GetClientInvoice(?)";
        List<String[]> invoices = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, clientId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String[] invoice = new String[10];
                invoice[0] = rs.getString("invoice_id");
                invoice[1] = rs.getString("first_name") + " " + rs.getString("last_name");
                invoice[2] = rs.getString("rfc");
                invoice[3] = rs.getString("postal_code");
                invoice[4] = rs.getString("project_name");
                invoice[5] = rs.getString("stage_name");
                invoice[6] = rs.getString("date_issued");
                invoice[7] = rs.getString("subtotal");
                invoice[8] = rs.getString("total");
                invoice[9] = rs.getString("cfdi_code");
                invoices.add(invoice);
            }
        }

        return invoices;
    }

    public List<String[]> getInvoiceDetails(int invoiceId) throws SQLException {
        String sql = "CALL GetInvoiceDetails(?)";
        List<String[]> details = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, invoiceId);
            ResultSet rs = stmt.executeQuery();

            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (rs.next()) {
                String[] detail = new String[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    detail[i - 1] = rs.getString(i);
                }
                details.add(detail);
            }
        }

        return details;
    }

    public boolean deleteInvoice(int invoiceId) throws SQLException {
        String sql = "DELETE FROM invoice WHERE invoice_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, invoiceId);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        }
    }

}
